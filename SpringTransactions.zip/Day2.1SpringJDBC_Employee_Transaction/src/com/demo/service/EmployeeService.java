package com.demo.service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.domain.Employee;
//@Transactional
public interface EmployeeService {
	// Method to update employee details such as address and base location
	void updateEmployee(Employee employee)  ;
}
