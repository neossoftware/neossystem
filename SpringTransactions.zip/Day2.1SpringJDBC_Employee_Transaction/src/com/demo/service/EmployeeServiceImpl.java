package com.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.domain.Employee;
import com.demo.repository.AddressRepository;
import com.demo.repository.EmployeeRepository;
@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	AddressRepository addressDao;
	@Autowired
	private EmployeeRepository employeeDao;
	public void setEmployeeDao(EmployeeRepository employeeDao) {
		this.employeeDao = employeeDao;
	}
	public void setAddressDao(AddressRepository addressDao) {
		this.addressDao = addressDao;
	}
  
	@Override
	// @Transactional 
	public void updateEmployee(Employee employee)   {
		// Method to update new base location in Employee table and address in address table
		 employeeDao.update(employee.getEmpId(), employee.getBaseLocation());
		  addressDao.update(employee.getAddress());
	}
}
