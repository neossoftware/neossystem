package com.demo.client;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;

import com.demo.domain.Address;
import com.demo.domain.Employee;
import com.demo.service.EmployeeService;
public class ClientLogic {
	public static void main(String[] args) throws Throwable {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		EmployeeService empService = (EmployeeService) context.getBean("employeeService");
		
		
		 
		Address addr = new Address(101, "Mexicoooo", "610023");
		String baseloaction="Mexico";
		int empId=10001; 
		
		Employee employee = new Employee();
		employee.setEmpId(empId);
		employee.setDepartment("ETA");
		employee.setEmpName("Seema");
		employee.setBaseLocation(baseloaction);
		employee.setAddress(addr);
		try {
			// Method to update employee new address and base location details
			empService.updateEmployee(employee);
			System.out.println(employee);
			System.out.println(addr);
			System.out.println("Update Successful..");
		} catch ( Exception exp) {
			//System.out.println("Update Successful..");
			System.out.println(exp.getMessage());
		}
		context.close(); 
	}
}
