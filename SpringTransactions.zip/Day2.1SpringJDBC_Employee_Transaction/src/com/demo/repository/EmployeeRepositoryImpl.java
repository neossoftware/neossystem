package com.demo.repository;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository 
public class EmployeeRepositoryImpl implements EmployeeRepository {
JdbcTemplate jdbcTemplate;
@Autowired
public void setDataSource(DataSource dataSource)
{
	jdbcTemplate=new JdbcTemplate(dataSource);
}
	public void update(int empId,String newLocation)   {
	 
		String sql="update employeet set baseLocation=? where empId=?";
		
		int x=jdbcTemplate.update(sql,newLocation,empId);
		System.out.println(x);
	 
			 
		 
	}
}
