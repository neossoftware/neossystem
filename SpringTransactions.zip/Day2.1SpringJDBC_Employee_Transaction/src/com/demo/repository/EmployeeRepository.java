package com.demo.repository;
public interface EmployeeRepository {
	// Method to update employee base location
	public void update(int empid,String location)  ;
}
