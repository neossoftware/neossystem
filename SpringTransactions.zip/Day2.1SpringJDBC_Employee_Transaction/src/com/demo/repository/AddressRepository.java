package com.demo.repository;
import com.demo.domain.Address;
public interface AddressRepository {
	public void update(Address address);

}
