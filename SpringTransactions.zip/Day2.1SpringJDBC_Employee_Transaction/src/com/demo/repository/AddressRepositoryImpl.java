package com.demo.repository;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.demo.domain.Address;
@Repository
public class AddressRepositoryImpl implements AddressRepository {

NamedParameterJdbcTemplate namedParameterJdbcTemplate;
@Autowired
public void setDataSource(DataSource dataSource)
{
	namedParameterJdbcTemplate=new NamedParameterJdbcTemplate(dataSource);
}
	public void update(Address address) {
		String sql="update addresst set city=:city, pincode=:pincode where addressId=:addressId";
		SqlParameterSource s=new BeanPropertySqlParameterSource(address);
		namedParameterJdbcTemplate.update(sql, s);
		System.out.println("Here");
	}

}
