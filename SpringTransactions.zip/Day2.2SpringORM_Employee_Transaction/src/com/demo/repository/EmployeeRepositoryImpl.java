package com.demo.repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.demo.domain.Employee;
@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {

	@PersistenceContext
	private EntityManager entityManager;

	public void insert(Employee employee) {
		entityManager.persist(employee);
	}

	public void update(Employee emp) {
		Employee employee = (Employee) entityManager.find(Employee.class, emp.getEmpId());
		employee.setBaseLocation(emp.getBaseLocation());
		employee.setAddress(emp.getAddress());
		entityManager.merge(employee);
	}

}
