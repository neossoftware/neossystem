package com.demo.repository;
import com.demo.domain.Employee;
public interface EmployeeRepository {
	// Method to update employee base location
	public void update(Employee emp);
    // Method to insert employee record
	public void insert(Employee employee);
}
