package com.demo.client;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;

import com.demo.domain.Address;
import com.demo.domain.Employee;
import com.demo.service.EmployeeService;
public class ClientLogic {
	public static void main(String[] args) throws Throwable {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		EmployeeService empService = (EmployeeService) context.getBean("employeeService");

		Address addr = new Address(1002, "MCity,Chennai", "610004");
		Employee employee = new Employee(102, "Smith", "IVS", "Chennai", addr);

		empService.insertEmployee(employee);
		Address address = new Address(1002, "Ecity,Bangalore", "610023");

		employee.setBaseLocation("Bangalore");
		employee.setAddress(address);

		try {
			// Method to update employee new address and base location details
			empService.updateEmployee(employee);
			System.out.println("Update Successful..");
		} catch (DataAccessException exp) {
			System.out.println(exp.getMessage());
		}
		context.close();
	}
}
