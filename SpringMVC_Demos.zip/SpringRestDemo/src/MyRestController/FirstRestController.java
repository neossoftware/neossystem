/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyRestController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/myrest")
public class FirstRestController {
    
   @RequestMapping(method=RequestMethod.GET, produces="text/html")
   @ResponseBody
    public String show()
    {
        return "<h2><b>This is from FirstRest Controller!!</b></h2>"  ;
    }
    
    @RequestMapping(value="/sub",method=RequestMethod.GET, produces="text/html")
    @ResponseBody
    public String show1()
    {
      return "<H4>This is another Restful service from FirstRest Controller!!</H4>"  ;
    }
    
     @RequestMapping(value="/path/{param1}",method=RequestMethod.GET, produces="text/html")
   @ResponseBody
    public String show2(@PathVariable("param1")String s1)
    {
      return "<H4>This is another Restful service from FirstRest Controller with parameter :"+s1+"</H4>"  ;
    }
    
    @RequestMapping(value="/query",method=RequestMethod.GET, produces="text/html")
   @ResponseBody
    public String show3(@RequestParam("param1")String s1)
    {
      return "<H4>This is another Restful service from FirstRest Controller with query parameter :"+s1+"</H4>"  ;
    }
}
