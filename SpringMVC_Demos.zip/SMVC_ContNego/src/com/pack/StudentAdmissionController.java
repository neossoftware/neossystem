package com.pack;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@SessionAttributes("st")
@Controller
public class StudentAdmissionController {

	@RequestMapping(value = "/admissionForm", method = RequestMethod.GET)
	public ModelAndView getAdmissionForm() {
		ModelAndView model = new ModelAndView("AdmissionForm");
		return model;
	}

	@ModelAttribute
	public void addingCommonObjects(Model model) {
		model.addAttribute("headerMessage", "Institute");
	}

	@RequestMapping(value = "/submitAdmissionForm", method = RequestMethod.POST)
	public ModelAndView submitAdmissionForm(ModelMap m, @ModelAttribute("student") Student student) {

		/*
		 * @RequestParam(value="studentName") String name, @RequestParam("studentHobby")
		 * String hobby
		 */

		/*
		 * Student student1 = new Student(); student1.setStudentName(name);
		 * student1.setStudentHobby(hobby);
		 */

		ModelAndView model = new ModelAndView("AdmissionSuccess");
		m.addAttribute("st", student);
		/* model.addObject("headerMessage", "Private College"); */

		/* model.addObject("student1", student1); */

		return model;
	}
	
	@RequestMapping(value="/ticket.pdf", method = RequestMethod.GET)
    public void downloadTicket(Model model,HttpSession session) throws Exception {
        String studentName = ((Student)session.getAttribute("st")).getStudentName().toString();
        String studentHobby = ((Student)session.getAttribute("st")).getStudentHobby().toString();
        String studentMobile = ((Student)session.getAttribute("st")).getStudentMobile().toString();
        String studentDOB = ((Student)session.getAttribute("st")).getStudentDOB().toString();
        //List<String> studentSkills = ((Student)session.getAttribute("student")).getStudentSkills().toString();
        model.addAttribute("studentName", studentName);
        model.addAttribute("studentHobby", studentHobby);
        model.addAttribute("studentMobile", studentMobile);
        model.addAttribute("studentDOB", studentDOB);
    }
}
