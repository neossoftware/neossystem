package com.pack;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller

public class MyController {


	// Receive Locale and HttpServletRequest
		@RequestMapping("/hello")
		public String helloMethod(Model model, Locale locale,	HttpServletRequest request,HttpSession session) {
			model.addAttribute("country", locale.getCountry());
			model.addAttribute("ContextPath",request.getContextPath());
			session.setAttribute("Message","Hi, Good Morning");
			return "success";
		}

		// Display a request header with explicit name
		@RequestMapping("/welcome")
		public String welcomeMethod(@RequestHeader("Accept-Language") String language,
				                              @RequestHeader("Accept") String acceptType,Model model,HttpSession session) {
			model.addAttribute("accepttype",acceptType);
			model.addAttribute("acceptLanguage", language);
			System.out.println(session.getAttribute("Message"));
			return "welcome";
			
		}

}
