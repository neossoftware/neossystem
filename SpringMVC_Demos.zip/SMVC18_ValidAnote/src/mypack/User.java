package mypack;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

public class User {
	@NotEmpty(message = "Username must not be blank.")
	private String name;
	
	@NotEmpty(message = "Password must not be blank.")
	@Size(min=3,max=10 , message = "Password must between 8 to 10 Characters.")
	private String pwd;
		
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
}
//Date - before today, after today
// So many annotations String fucntionalties
//Integer
