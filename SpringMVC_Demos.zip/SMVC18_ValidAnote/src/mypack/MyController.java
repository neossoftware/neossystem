package mypack;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
@RequestMapping("/register.htm")
public class MyController {
	@Autowired  
	private Validator validator;
	
	public Validator getValidator() {
		return validator;
	}
	public void setValidator(Validator validator) {
		this.validator = validator;
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder){
		System.out.println("in binder");
		binder.setValidator(validator);
	}
	@RequestMapping(method = RequestMethod.GET)
	public String showForm(ModelMap m){
		User user=new User();
		m.addAttribute("user", user);
		return "/register.jsp";
	}
	@RequestMapping(method = RequestMethod.POST)
	public String onSubmit(@Valid User user,BindingResult result){
		if(result.hasErrors()){
			return "/register.jsp";
		}
		//call to service layer to do login validation..
		return "/success.jsp";
	}
}
