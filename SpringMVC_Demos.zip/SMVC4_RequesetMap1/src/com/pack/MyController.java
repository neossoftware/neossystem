package com.pack;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value="/book/{item}",method=RequestMethod.GET)
public class MyController {

	@RequestMapping(params="bookcategory=technical",headers="Accept=application/xaml+xml")
	public String processBooks(@PathVariable String item){
		System.out.println("You had selected the book:" + item);
		return "success";
	}
	
	@RequestMapping(params="bookcategory=general")
	public String process(@PathVariable("item") String item){
		System.out.println("You had selected the book:" + item);
		return "failure";
	}
	
}
