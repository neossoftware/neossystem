package mypack;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value="/register.htm")
public class RegistrationController {
	@RequestMapping(method = RequestMethod.POST)
	public String processRegistration(@RequestParam("uname")String uname,
			@RequestParam("pass")String pass, ModelMap map){
		
		Employee emp=new Employee();
		emp.setUname(uname);
		emp.setPass(pass);
		
		map.addAttribute("emp",emp);
		
	//	return "forward:/update.htm"; 
		return "redirect:/update.htm"; 
	}
	
	
}
