package mypack;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class RegistrationController {

	@RequestMapping(value="/register.htm",method = RequestMethod.POST)
	public String onSubmit(@ModelAttribute("emp") Employee emp , RedirectAttributes redirectAttr){
		redirectAttr.addFlashAttribute("emp", emp);
		return "redirect:/output.htm";
	}
            @RequestMapping(value="/output.htm")
	public String renderResult(@ModelAttribute("emp") Employee emp){
		System.out.println("EmployeeName:"+emp.getUname());
		return "final";
            }
}
