package mypack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@Autowired
	private UserDetails userDetails;
        
	@RequestMapping("/hello.htm")
	public String getMethod(@ModelAttribute UserDetails userDetails){
		System.out.println("User Name : " + userDetails.getUserName());
		System.out.println("Email Id : " + userDetails.getEmailId());
		return "/WEB-INF/jsp/demo.jsp";
	}

	//This method is invoked before the above method
	@ModelAttribute
	public UserDetails getAccount(){
		
		userDetails.setUserName("lakshmi");
		userDetails.setEmailId("asd@gmail.com");
		return userDetails;
	}
}

