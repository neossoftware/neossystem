package pack;

public class Student {
    String name;
       int id;
       Address address;

     public Student(String name, int id) {
    	this.name = name;
    	this.id = id;
    
	}
	public String getName() {
   	 return name;
	}
  public void setName(String name) {
 		 this.name = name;
  }
	public int getId() {
  	     	return id;
}
public void setId(int id) {
     	this.id = id;
}
public Address getAddress() {
    	return address;
}
public void setAddress(Address address) {
    	this.address = address;
}
}
