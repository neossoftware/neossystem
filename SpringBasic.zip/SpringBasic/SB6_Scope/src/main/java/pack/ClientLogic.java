package pack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientLogic {
    public static void main(String[] args) {
       ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
       Student s=(Student)context.getBean("student");
       System.out.println("-----First time access to Student bean------");
       System.out.println("Student Name: "+s.getName());
       System.out.println("Student Id: "+ s.getId());
       System.out.print("Address: "+s.getAddress().getCity());
       System.out.println("-" + s.getAddress().getPincode());
       
       s.setName("Bob");
       s.setId(1011);
       System.out.println("-----details after resetting values for name and id------");
       System.out.println("Student Name: "+s.getName());
       System.out.println("Student Id: "+ s.getId());
       System.out.print("Address: "+s.getAddress().getCity());
       System.out.println("-" + s.getAddress().getPincode());
      
       Student s1=(Student)context.getBean("student");
       System.out.println("-----Second time access to Employee bean------");
       System.out.println("Student Name: "+s1.getName());
       System.out.println("Student Id: "+ s1.getId());
       System.out.print("Address: "+s1.getAddress().getCity());
       System.out.println("-" + s1.getAddress().getPincode());
    }
}
