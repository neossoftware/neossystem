package pack;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class ConfigClass { 
   @Bean
    Address address() {
                       Address address=new Address("Bangalore",560082);
                       return address;     
    } 
    
    @Bean
    Student student() {
                         Student s=new Student();
                         s.setName("Smith");
                         s.setAddress(address());
                         return s;
	      
    } 
    @Bean
    CourseReg creg() {
              CourseReg cr = new CourseReg();
              cr.setCname("Maths");
              cr.setCcode("101");
              cr.setStud(student());
              return cr;   
    } 
}
