package pack;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

	@Component
	@Aspect
	public class MyAspect {


	@Before("execution(* pack.*.show(..))")
	public void beforeAdvice()
	    {
	    System.out.println("Before the actual business logic.");
	}

	@After("execution(* pack.*.show(..))")
	public void afterAdvice()
	    {
	    System.out.println("After the actual busines logic.");
	}

	@AfterReturning(pointcut="execution(* pack.*.show(..))", returning="rvalue")
	public void afterReturningAdvice(int rvalue)
	    {
	    System.out.println("Returning value:"+ rvalue);
	}

	@AfterThrowing(pointcut="execution(* pack.*.show(..))", throwing="exc")
	public void afterThrowingAdvice(Exception exc)
	    {
	    System.out.println("An exception has been raised:"+exc.toString());
	}
	
    @Around("execution(* pack.CourseReg.show(..))")
    public int invoke(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("Around Advice: Before calling actual method\n");
		 joinPoint.proceed();
		System.out.println("Around Advice: After calling actual method\n");
            return 2;
    }
}
