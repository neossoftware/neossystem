package pack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class ClientLogic {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        CourseReg register = (CourseReg)context.getBean("creg");
        System.out.println(" ......................................"); 
        System.out.println(" First time calling") ;
        System.out.println(" .......................................");
        try{
           register.show(true);
        }
        catch(Exception e){
           System.out.println(e);
       }
       System.out.println(" .........................................."); 
       System.out.println(" Second time calling") ;
       System.out.println(" ..........................................");
       try{
            register.show(false);
        }
       catch(Exception e){
          System.out.println(e);
      }
    }
}
