package pack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("creg")
public class CourseReg {
    @Autowired
    private Student stud;
    @Value("Math")
    private String cname;
    @Value("101")
    private String ccode;
    public String getCcode() {
       return ccode;   
  }
    public void setCcode(String ccode) {
        this.ccode = ccode;    
 }
    public String getCname() {
        return cname;
   }
        public void setCname(String cname) {
        	this.cname = cname;
    }
    public Student getStud() {
     	return stud;
    }
    public void setStud(Student stud) {
            this.stud = stud;
    }
    /* method argument boolean is to demonstrate AfterThrowing advice concept */
    public int show(boolean b)throws Exception{
         if(b){
        System.out.println("Student name:" + stud.getName());
        System.out.print("City:" + stud.getAddress().getCity());
        System.out.println(","+"Pincode-" + stud.getAddress().getPincode());
        System.out.println("Course name:" + getCname());
        System.out.println("Course code:" + getCcode());
        return 1;
        }
        else{
          throw new ArithmeticException("Not valid data");
	}
    }
 }
