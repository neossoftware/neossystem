package pack;

public class WelcomeBean {
	private String message="Hi, Welcome to Spring. Happy learning!!"; 
	public void show() {  
		System.out.println(message);
	}    
	

}
