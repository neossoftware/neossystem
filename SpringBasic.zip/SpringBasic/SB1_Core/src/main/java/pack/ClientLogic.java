package pack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientLogic {
	public static void main(String[] args){ 
			
	    ApplicationContext context = new ClassPathXmlApplicationContext("spconfig.xml");
          Object obj=context.getBean("id1");
   	    WelcomeBean wb = (WelcomeBean)obj;      
	    wb.show();   
		
	}
}
