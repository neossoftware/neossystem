package pack;


import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class ClientLogic {
    public static void main(String[] args) {
       AbstractApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
       Student s=(Student)context.getBean("student");
       System.out.println("Student Name: "+s.getName());
       System.out.println("Student Id: "+ s.getId());
       context.close();
    }
}
