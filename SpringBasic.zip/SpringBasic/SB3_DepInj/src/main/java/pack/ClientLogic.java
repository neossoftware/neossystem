package pack;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class ClientLogic {
    public static void main(String[] args) {
       ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
       Student s=(Student)context.getBean("student");
       System.out.println("Student Name: "+s.getName());
       System.out.println("Student Id: "+ s.getId());
       System.out.print("Address: "+s.getAddress().getCity());
       System.out.println("-" + s.getAddress().getPincode());
    }
}

