package pack;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientLogic {
    public static void main(String[] args) {
        BeanFactory beanfactory = new ClassPathXmlApplicationContext("config.xml");
        CourseReg register = (CourseReg)beanfactory.getBean("creg");
        System.out.println(register);
    }
}
