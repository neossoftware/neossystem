package pack;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
class Address {
	@Value("Mysore")
    String city;
	@Value("570001")
    int pincode;
   
    
    public Address(String city, int pincode) {
        this.city = city;
        this.pincode = pincode;
    }
    
    public Address() {
       
    }
     public String getCity() {
        return city;
    }
public void setCity(String city) {
        this.city = city;
    }
    public int getPincode() {
        return pincode;
    }
    public void setPincode(int pincode) {
        this.pincode = pincode;
    }  
    public String toString() {
        return "[City=" + city + ", pincode=" + pincode + "]";
    }
}
