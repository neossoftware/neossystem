import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { BookService } from './book/book.service'
import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';
import { Interceptor1 } from './book/book.interceptor';

@NgModule({
  imports: [BrowserModule, HttpClientModule],
  declarations: [AppComponent, BookComponent],
  providers: [BookService, {
    provide: HTTP_INTERCEPTORS,
    useClass: Interceptor1,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
