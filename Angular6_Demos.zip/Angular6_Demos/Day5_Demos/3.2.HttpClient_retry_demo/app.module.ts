import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http'
import { BookService } from './book/book.service'
import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';


@NgModule({
  imports: [BrowserModule, HttpClientModule],
  declarations: [AppComponent,BookComponent],
  providers: [BookService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
