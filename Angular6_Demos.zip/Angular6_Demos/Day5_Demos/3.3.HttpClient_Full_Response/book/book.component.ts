import { Component, OnInit } from '@angular/core';
import { BookService } from './book.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  books:any[];
  errorMessage: string;

  constructor(private bookService: BookService) { }

  getBooks() {
    this.bookService.getBooks().subscribe(
      response => this.books = response.body,
      error => this.errorMessage = <any>error);
  }

  ngOnInit() {
    this.getBooks();
  }
}
