import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { catchError, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { Book } from './book';

@Injectable()
export class BookService {

  private booksUrl = './assets/books.json';

  constructor(private http: HttpClient) { }

  getBooks(): Observable<HttpResponse<Book[]>> {
    return this.http.get<Book[]>(this.booksUrl,{observe:'response'}).pipe(
      tap(books => console.log(books.headers.get('date'))),
      catchError(this.handleError))
  }
  private handleError(error: any) {
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}
