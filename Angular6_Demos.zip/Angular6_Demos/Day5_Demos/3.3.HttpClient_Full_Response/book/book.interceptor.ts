import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class Interceptor1 implements HttpInterceptor {
  intercept (req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
  
  const secureReq = req.clone({
  headers: req.headers.set('Authorization23', 'Password')});
   return next.handle(secureReq);
  } 
}


 // const authReq = req.clone({
    // headers: req.headers.set('Authorization23', 'Password')
   // });
 //  return next.handle(authReq);
    //const dupReq = req.clone();