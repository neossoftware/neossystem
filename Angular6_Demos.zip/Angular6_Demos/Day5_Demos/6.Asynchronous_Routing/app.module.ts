import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { BookService } from './book/book.service';

import { DashboardComponent } from './dashboard/dashboard.component';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { AppRoutingModule } from './app-routing.module';
import { LoginComponent } from './login/login.component';
import {LoginService } from './login/login.service';
import {LoginGuardService} from './login/login-guard.service';

@NgModule({
  imports: [BrowserModule, HttpClientModule, FormsModule, ReactiveFormsModule, AppRoutingModule],
  declarations: [AppComponent, DashboardComponent, BookDetailComponent, LoginComponent],
  providers: [BookService,  LoginService, LoginGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
