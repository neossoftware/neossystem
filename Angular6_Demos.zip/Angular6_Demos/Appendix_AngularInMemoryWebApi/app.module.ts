import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule }     from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';

import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';
import { BookService } from './book/book.service';
import { InMemoryMockDataService } from './book/in-memory-mock-data.service';

@NgModule({
  imports: [BrowserModule, HttpClientModule, HttpClientInMemoryWebApiModule.forRoot(InMemoryMockDataService)],
  declarations: [AppComponent, BookComponent],
  providers: [BookService, InMemoryMockDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
