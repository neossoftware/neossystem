import { Component, OnInit } from '@angular/core';

import { Book } from './book';
import { BookService } from './book.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  books: Book[];
  errorMessage: string;

  constructor(private bookService: BookService) { }

  getBooks() {
    this.bookService.getBooks().subscribe(
      books => this.books = books,
      error => this.errorMessage = <any>error);
  }

  addBook(bookName: string) {
    let book = new Book();
    book.name = bookName;
    this.bookService.addBook(book)
      .subscribe(
      book => this.books.push(book),
      error => this.errorMessage = <any>error);
  }

  deleteBook(bookId: number) {
    this.bookService.deleteBook(bookId)
      .subscribe(
      book => this.getBooks(),
      error => this.errorMessage = error);

  }

  updateBook(bookId: number, bookName: string) {
    let book: Book = new Book();
    book.id = Number(bookId);
    book.name = bookName;
    this.bookService.updateBook(book)
      .subscribe(
      book => this.getBooks(),
      error => this.errorMessage = error);
  }
  ngOnInit() {
    this.getBooks();
  }
}
