import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = "product details";
  productCode: string = "PROD_P001";
  productName: string = "Apple MPTT2 MacBook Pro";
  productPrice: number = 217021;
  purchaseDate: string = "1/17/2018";
  productTax: string = "0.1";
  productRating: number = 4.92;


}