import { Component } from '@angular/core';

@Component({
  selector: 'app-child',
  styles: [`
        .highlight {
            border: 2px solid violet;
            background-color:cornsilk;
            text-align: center;
            margin-bottom: 20px;
        }
    `],
  templateUrl: './child.component.html'
})
export class ChildComponent{
}
