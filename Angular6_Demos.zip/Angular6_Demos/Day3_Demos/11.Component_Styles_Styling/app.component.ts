import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  styles: [`
        .highlight {
            border: 2px solid coral; 
            background-color:AliceBlue;
            text-align: center;
            margin-bottom: 20px;
        }
    `],
    templateUrl: './app.component.html'
})
export class AppComponent {
}

