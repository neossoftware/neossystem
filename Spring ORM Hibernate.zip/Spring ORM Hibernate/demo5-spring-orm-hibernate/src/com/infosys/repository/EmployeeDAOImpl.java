package com.infosys.repository;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infosys.domain.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public List<Employee> getAll() {
		Session session = sessionFactory.openSession();
		

		
//		Criteria query1 = session.createCriteria(Employee.class);
//		List<Employee> empList1 = query1.list();
		
		// Create CriteriaQuery
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Employee> query = builder.createQuery(Employee.class);
        Root<Employee> root = query.from(Employee.class);
        query.select(root);
        
        
        
        List<Employee> empList=session.createQuery(query).getResultList();
        return empList;
	}

	public void update(int empId, String department) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Employee emp = (Employee) session.get(Employee.class, empId);
		emp.setDepartment(department);
		//session.update(emp);
		tx.commit();
		session.close();
	}
}
