package com.pack.ars.exception;
@SuppressWarnings("serial")
public class CreditCardNotFoundException extends Exception {


	public CreditCardNotFoundException(String message) {
		super(message);
	}
}