package com.pack.ars.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.ars.entity.UserEntity;
import com.pack.ars.exception.UserNotFoundException;
import com.pack.ars.model.User;
import com.pack.ars.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
public User getUserDetails(String userId) throws UserNotFoundException{
		
		
		UserEntity ue = userRepository.findOne(userId);
		
		
		
		
		if (ue == null){			
			throw new UserNotFoundException(
					"UserService.USER_NOT_FOUND");
		}
		User user = new User();
		user.setCity(ue.getCity());
		user.setEmail(ue.getEmail());
		user.setName(ue.getName());
		user.setPhone(ue.getPhone());
		user.setUserId(ue.getUserId());
		
			return user;				
		

	}
	

}
