/**
 * 
 */
package com.pack.ars.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.ars.entity.UserEntity;
import com.pack.ars.exception.InvalidCredentialException;
import com.pack.ars.model.Login;
import com.pack.ars.repository.UserRepository;


/**
 * The Class AadharService.
 */
@Service

public class LoginService {

	@Autowired
	private UserRepository userRepository;	
	//@Autowired
	//private CounterService counterService;
	
	
	public UserEntity authenticateLogin(Login userLogin) throws InvalidCredentialException{
		
		
		UserEntity user = userRepository.findOne(userLogin.getUserName());
		
		
		
		
		if (user == null){	
		//	counterService.increment("counter.login.failure");
			
			throw new InvalidCredentialException(
					"LoginService.INVALID_CREDENTIALS");
		}
		else if(!(user.getPassword().equals(userLogin.getPassword()))){
			//counterService.increment("counter.login.failure");
			throw new InvalidCredentialException(
					"LoginService.INVALID_CREDENTIALS");
		}
		//counterService.increment("counter.login.success");
	
			return user;				
		

	}
	

	
	
}
