package com.pack.ars.exception;

@SuppressWarnings("serial")
public class SourceNotFoundException extends Exception {
	public SourceNotFoundException(String message) {
		super(message);
	}

}
