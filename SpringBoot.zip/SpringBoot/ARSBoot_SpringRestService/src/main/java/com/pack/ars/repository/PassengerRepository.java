package com.pack.ars.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pack.ars.entity.PassengerEntity;

public interface PassengerRepository extends JpaRepository<PassengerEntity, Integer>{

}
