package com.pack.ars.exception;

@SuppressWarnings("serial")
public class SeatsNotAvaialbleException extends Exception{
	public SeatsNotAvaialbleException(String message){
		super(message);
	}

}
