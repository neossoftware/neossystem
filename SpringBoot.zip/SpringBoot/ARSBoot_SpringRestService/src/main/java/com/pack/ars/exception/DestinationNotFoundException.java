package com.pack.ars.exception;
@SuppressWarnings("serial")
public class DestinationNotFoundException extends Exception {


	public DestinationNotFoundException(String message) {
		super(message);
	}


}
