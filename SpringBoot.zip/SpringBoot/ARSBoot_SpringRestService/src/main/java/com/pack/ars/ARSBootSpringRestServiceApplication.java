package com.pack.ars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ARSBootSpringRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ARSBootSpringRestServiceApplication.class, args);
	}
}
