/**
 * 
 */
package com.pack.ars.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.ars.entity.FlightEntity;
import com.pack.ars.exception.FlightNotAvailableException;
import com.pack.ars.exception.InvalidJourneyDateException;
import com.pack.ars.exception.InvalidSourceDestinationException;
import com.pack.ars.model.SearchFlights;
import com.pack.ars.repository.FlightRepository;
import com.pack.ars.utility.CalendarUtility;;

/**
 * The Class AadharService.
 */
@Service
public class FlightService {
	
	@Autowired
	private FlightRepository flightsRepository;
	 protected String baseUrl;

	public List<String> getSources() {
		List<String> sources = flightsRepository.findFlightSources();
		
			return sources;
		
	}
	
	public List<String> getDestinations() {
		List<String> destinations = flightsRepository.findFlightDestinations();
		
			return destinations;
		
	}

	public  List<SearchFlights> getFlights(String source, String destination, Calendar journeyDate) throws InvalidSourceDestinationException,FlightNotAvailableException, InvalidJourneyDateException, Exception	 {
		
		Calendar today = Calendar.getInstance();
		if(today.after(journeyDate))
			throw new InvalidJourneyDateException("FlightService.INVALID_JOURNEYDATE");
		if(source.equalsIgnoreCase(destination)){
		
			
			throw new InvalidSourceDestinationException("FlightService.INVALID_SOURCE_DESTINATION");
		}
		 List<FlightEntity> flights = flightsRepository.findFlightDetails(source, destination, journeyDate);
		 
		if (flights == null || flights.isEmpty()) {
			throw new FlightNotAvailableException("FlightService.FLIGHT_NOT_AVAILABLE");
		} 
		
		List<SearchFlights> availableFlights = new ArrayList<SearchFlights>();
		for (FlightEntity f : flights) {
			SearchFlights flight = new SearchFlights();
			flight.setFlightId(f.getFlightId());
			flight.setSource(f.getSource());
			flight.setDestination(f.getDestination());
			flight.setFlightAvailableDate(CalendarUtility.getStringFromCalendar(f.getFlightAvailableDate()));
			flight.setDepartureTime(f.getDepartureTime());
			flight.setArrivalTime(f.getArrivalTime());
			flight.setSeatCount(f.getSeatCount().toString());
			flight.setAirlines(f.getAirlines());
			flight.setFare(Double.toString(f.getFare()));
			availableFlights.add(flight);
			
		}
			return availableFlights;
		
		

	}

	
	/*public void updateFlight(String flightId, String noOfSeats) throws ARSServiceException {
		FlightEntity flight = flightsRepository.findOne(flightId);
		if(flight == null){
			throw new ARSServiceException("No flight for the given details");
		}
		else{
			
			int count = flight.getSeatCount() - Integer.valueOf(noOfSeats);
			flight.setSeatCount(count);
			flightsRepository.saveAndFlush(flight);
			
			
			
		}
		
		
	}*/
	
	
	
	public void updateSeatsDetails(HttpServletRequest request,String flightId, int noOfSeats) {
		if (baseUrl == null) {
			getBaseUrl(request);
		}
		//String url = baseUrl + "/flights/" + flightId + "/" + noOfSeats + "/";

		//restTemplate.put(url, flightId, noOfSeats);

	}

	public void reliable(String flightId, int noOfSeats) {

	}

	private void getBaseUrl(HttpServletRequest request) {
		
		this.baseUrl= request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
		/*List<ServiceInstance> instances = discoveryClient.getInstances("flights-microservice");
		System.out.println(instances.size());
		ServiceInstance serviceInstance = instances.get(0);
		System.out.println(serviceInstance);
		baseUrl = serviceInstance.getUri().toString();*/

		this.baseUrl = baseUrl.startsWith("http") ? baseUrl : "http://" + baseUrl;
	}

}
