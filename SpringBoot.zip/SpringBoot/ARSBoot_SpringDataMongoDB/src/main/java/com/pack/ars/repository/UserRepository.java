package com.pack.ars.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.pack.ars.document.UserDocument;

public interface UserRepository extends MongoRepository<UserDocument, String>{

}
