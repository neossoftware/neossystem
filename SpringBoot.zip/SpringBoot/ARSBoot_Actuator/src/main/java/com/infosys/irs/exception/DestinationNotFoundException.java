package com.infosys.irs.exception;
@SuppressWarnings("serial")
public class DestinationNotFoundException extends Exception {


	public DestinationNotFoundException(String message) {
		super(message);
	}


}
