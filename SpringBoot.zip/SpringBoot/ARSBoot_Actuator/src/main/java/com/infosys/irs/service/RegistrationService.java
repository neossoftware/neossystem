package com.infosys.irs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.infosys.irs.entity.UserEntity;
import com.infosys.irs.exception.UserIdAlreadyPresentException;
import com.infosys.irs.model.User;
import com.infosys.irs.repository.UserRepository;

@Service
public class RegistrationService {
	
	@Autowired
	private UserRepository userRepository;
	
	public void registerUser(User user) throws UserIdAlreadyPresentException{
		Long time1, time2;
        time1 = System.currentTimeMillis();
		UserEntity ue = findUser(user.getUserId());
		time2 = System.currentTimeMillis();
        System.out.println("Amount of time taken:"+(time2-time1)+" miliseconds.");
		if(ue!=null)
			throw new UserIdAlreadyPresentException("RegistrationService.USERID_PRESENT");
		UserEntity userEntity = new UserEntity();
		userEntity.setCity(user.getCity());
		userEntity.setEmail(user.getEmail());
		userEntity.setName(user.getName());
		userEntity.setPassword(user.getPassword());
		userEntity.setPhone(user.getPhone());
		userEntity.setUserId(user.getUserId());
		userRepository.saveAndFlush(userEntity);		
	}
	
	@Cacheable("user")
    public UserEntity findUser(String userId) 
    {
        UserEntity userEntity=userRepository.findOne(userId);
        return userEntity;
    }
	
}
