/**
 * 
 */
package com.infosys.irs.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.metrics.CounterService;
import org.springframework.stereotype.Service;

import com.infosys.irs.entity.UserEntity;
import com.infosys.irs.exception.InvalidCredentialException;
import com.infosys.irs.model.Login;
import com.infosys.irs.repository.UserRepository;


/**
 * The Class AadharService.
 */
@Service

public class LoginService {

	@Autowired
	private UserRepository userRepository;	
	@Autowired
	private CounterService counterService;
	
	public UserEntity authenticateLogin(Login userLogin) throws InvalidCredentialException{
		UserEntity user = userRepository.findOne(userLogin.getUserName());
			
		if (user == null){	
			counterService.increment("counter.login.failure");
			
			throw new InvalidCredentialException(
					"LoginService.INVALID_CREDENTIALS");
		}
		else if(!(user.getPassword().equals(userLogin.getPassword()))){
			counterService.increment("counter.login.failure");
			throw new InvalidCredentialException(
					"LoginService.INVALID_CREDENTIALS");
		}
		counterService.increment("counter.login.success");
				return user;				
	}
}
