package com.pack.ars.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.ars.repository.FindUserRepository;

@Controller
public class UserController {
	@Autowired
	private FindUserRepository userRepository;
	
	@RequestMapping(value="/find.htm")
	public void findUser(@RequestParam("city")String city)
	{
		System.out.println(userRepository.findByCity(city));
	}

}
