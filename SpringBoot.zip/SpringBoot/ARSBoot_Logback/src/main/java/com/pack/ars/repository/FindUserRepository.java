package com.pack.ars.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pack.ars.entity.UserEntity;

public interface FindUserRepository extends JpaRepository<UserEntity, String> {
	 public UserEntity findByCity(String city);
	 
	// @Query(value="update UserEntity set pwd=:password where email=:email")
	 //   int updatePassword(@Param("email") String email, @Param("password") String password);



}
