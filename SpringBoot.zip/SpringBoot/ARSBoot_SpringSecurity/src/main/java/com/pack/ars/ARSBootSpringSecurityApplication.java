package com.pack.ars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ARSBootSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ARSBootSpringSecurityApplication.class, args);
	}
}
