package com.pack.ars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@PropertySource(value = {"classpath:configuration.properties"})
public class ARSBootYamlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ARSBootYamlApplication.class, args);
	}
}
