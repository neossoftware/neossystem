package com.demo;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HQLFunc_GRPHAV {
    private static SessionFactory sessionFactory;
    private static ServiceRegistry serviceRegistry;
    public static void main(String args[]) {
    Session session = null;
    try{
      try{
          Configuration cfg = new Configuration().configure("/com/demo/hibernate.cfg.xml");                    
          cfg.addAnnotatedClass(Customer.class);
          serviceRegistry = new ServiceRegistryBuilder().applySettings(      
                            cfg.getProperties()).buildServiceRegistry();
          sessionFactory = cfg.buildSessionFactory(serviceRegistry);
      }
      catch (Exception th) {
          System.err.println("Failed to create sessionFactory object."+ th.getMessage());
          throw new ExceptionInInitializerError(th);
      }
      session = sessionFactory.openSession();
      session.beginTransaction();
      //Group By
      Query query = session.createQuery("select city, count(*) from Customer group by city");
      for(Iterator it=query.iterate();it.hasNext();)
      {
       Object[] row = (Object[]) it.next();
       System.out.print("City: " + row[0]);
       System.out.println(" | Number of City: " + row[1]);
      }
      
      //Having
      query = session.createQuery("select city, count(*) from Customer group by city having count(*)>1");
      for(Iterator it=query.iterate();it.hasNext();)
      {
       Object[] row = (Object[]) it.next();
       System.out.print("City: " + row[0]);
       System.out.println(" | Number of City: " + row[1]);
      }
      session.getTransaction().commit();
     }
    catch (Exception e) {
        System.out.println(e.getMessage());
    }
    finally {
        session.close();
    }
  }
}