package com.infybank;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.hibernate.HibernateException;

public class CustomerAddressDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("1. New loan to new customer ");
		System.out.println("2. New loan to existing customer");
		System.out.println("Choose one option");
		int opt = sc.nextInt();
		switch (opt) {
		case 1:
			newCustomerNewAddress(sc);
			break;
		case 2:
			newCustomerExistingAddress(sc);
			break;
		default:
			System.out.println("Choose correct option");
		}

	}

	public static void newCustomerNewAddress(Scanner sc) {
		// TODO Auto-generated method stub
		CustomerDAO customerdao = new CustomerDAO();
		try {
			System.out.println("Enter the Customer details");
			System.out.println("Enter the Customer Id");
			int id = sc.nextInt();
			System.out.println("Enter the Customer name");
			String name = sc.next();
			System.out.println("Enter the Customer date of birth in MM/dd/yyyy format");
			String datestr = sc.next();
			SimpleDateFormat formatter = new SimpleDateFormat("mm/dd/yyyy");
			Date dob = (Date) formatter.parse(datestr);
			System.out.println("Enter the Customer phoneNo");
			long phone = sc.nextLong();
			System.out.println("Do you want to enter the address(Y/N)");
			String isAddress = sc.next();
			Address address = null;
			if (isAddress.compareToIgnoreCase("y") == 0) {
				System.out.println("Enter the Address details");
				System.out.println("Enter the Address Id");
				String addId = sc.next();
				System.out.println("Enter the Address Line");
				String line = sc.next();
				System.out.println("Enter the district");
				String dist = sc.next();
				System.out.println("Enter the State");
				String state = sc.next();
				System.out.println("Enter the Pincode");
				Long pincode = sc.nextLong();
				address = new Address(addId, line, dist, state, pincode);
			}
			Customer customer = new Customer(id, name, dob, address, phone);
			customerdao.newCustomerNewAddress(customer, address);
			System.out.println("One record created");
			sc.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			System.out.print(e);
		} catch (Exception e) {
			System.out.print(e);
		}
	}

	public static void newCustomerExistingAddress(Scanner sc) {
		// TODO Auto-generated method stub
		CustomerDAO customerdao = new CustomerDAO();
		try {
			System.out.println("Enter the Customer Id");
			Integer id=sc.nextInt();
			System.out.println("Enter the Address details");
			System.out.println("Enter the Address Id");
			String addId = sc.next();
			System.out.println("Enter the Address Line");
			String line = sc.next();
			System.out.println("Enter the district");
			String dist = sc.next();
			System.out.println("Enter the State");
			String state = sc.next();
			System.out.println("Enter the Pincode");
			Long pincode = sc.nextLong();
			Address address = new Address(addId, line, dist, state, pincode);
			customerdao.newCustomerExistingAddress(id, address);
			System.out.println("One record created");
			sc.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			System.out.print(e);
		} catch (Exception e) {
			System.out.print(e);
		}
	}
}