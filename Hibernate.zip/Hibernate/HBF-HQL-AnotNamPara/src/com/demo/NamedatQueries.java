package com.demo;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class NamedatQueries {
    private static SessionFactory sessionFactory;
    private static ServiceRegistry serviceRegistry;
    public static void main(String args[]) {
    Session session = null;
    try{
      try{
          Configuration cfg = new Configuration().configure("/com/demo/hibernate.cfg.xml");                    
          cfg.addAnnotatedClass(Customer.class);
          serviceRegistry = new ServiceRegistryBuilder().applySettings(      
                            cfg.getProperties()).buildServiceRegistry();
          sessionFactory = cfg.buildSessionFactory(serviceRegistry);
      }
      catch (Exception th) {
          System.err.println("Failed to create sessionFactory object."+ th.getMessage());
          throw new ExceptionInInitializerError(th);
      }
      session = sessionFactory.openSession();
      session.beginTransaction();
      //Named Parameters
      Query query = session.getNamedQuery("Customer.Read");  
      List<Customer> customers=query.list();  
            
      Iterator<Customer> itr=customers.iterator();  
       while(itr.hasNext()){  
      Customer e=itr.next();  
      System.out.println("Customer Data Reading: "+e);  
       }  
       
       session.getTransaction().commit();
       Query que = session.getNamedQuery("Customer.Update").setString("name","Sweta");  
       List<Customer> custs=que.list();  
             
       Iterator<Customer> iter=custs.iterator();  
        while(iter.hasNext()){  
       Customer cs=iter.next();  
       System.out.println("Customer Data Update: "+cs);  
        }  
 
      session.getTransaction().commit();
  }
    catch (Exception e) {
        System.out.println(e.getMessage());
    }
    finally {
        session.close();
    }
  }
}