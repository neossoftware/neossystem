package com.infybank.read;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class CustomerDAO implements ICustomer {
	public void addCustomer(Customer c1) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(c1);
		
		tx.commit();
		
		session.close();
	}
	
	public void readCustomer(int customerId) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Customer cust = (Customer) session.get(Customer.class, customerId);
		
		System.out.println("Name: " + cust.getCustomerName());
		session.close();
	}
}
