package com.infybank.read;

public interface ICustomer {
	public void addCustomer(Customer custObj);
	
	public void readCustomer(int customerId);
}
