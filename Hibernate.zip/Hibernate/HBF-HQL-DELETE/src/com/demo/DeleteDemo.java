package com.demo;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class DeleteDemo {
    private static SessionFactory sessionFactory;
    private static ServiceRegistry serviceRegistry;
    public static void main(String args[]) {
    Session session = null;
    try{
      try{
          Configuration cfg = new Configuration().configure("/com/demo/hibernate.cfg.xml");                    
          cfg.addAnnotatedClass(Customer.class);
          serviceRegistry = new ServiceRegistryBuilder().applySettings(      
                            cfg.getProperties()).buildServiceRegistry();
          sessionFactory = cfg.buildSessionFactory(serviceRegistry);
      }
      catch (Exception th) {
          System.err.println("Failed to create sessionFactory object."+ th.getMessage());
          throw new ExceptionInInitializerError(th);
      }
      session = sessionFactory.openSession();
      session.beginTransaction();
      //Delete Operation
      Query query = session.createQuery("delete Customer cust where cust.customerId=1002");
      int update = query.executeUpdate();
      if(update == 0 || update == 1){
         System.out.println(update + " row affected");
      }
      else{
         System.out.println(update + " rows affected");  
      }
      session.getTransaction().commit();
  }
    catch (Exception e) {
        System.out.println(e.getMessage());
    }
    finally {
        session.close();
    }
  }
}