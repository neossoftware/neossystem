package com.demo;

import java.util.List;
import java.util.Iterator;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class PositionPar {
    private static SessionFactory sessionFactory;
    private static ServiceRegistry serviceRegistry;
    public static void main(String args[]) {
    Session session = null;
    try{
      try{
          Configuration cfg = new Configuration().configure("/com/demo/hibernate.cfg.xml");                    
          cfg.addAnnotatedClass(Customer.class);
          serviceRegistry = new ServiceRegistryBuilder().applySettings(      
                            cfg.getProperties()).buildServiceRegistry();
          sessionFactory = cfg.buildSessionFactory(serviceRegistry);
      }
      catch (Exception th) {
          System.err.println("Failed to create sessionFactory object."+ th.getMessage());
          throw new ExceptionInInitializerError(th);
      }
      session = sessionFactory.openSession();
      session.beginTransaction();
      //Positional Parameters
      List query = session.createQuery("from Customer c where c.customerName=?")
      .setString(0, "Sharon")
      .list();
      Iterator iter = query.iterator();
      if (!iter.hasNext()){
          System.out.println("No name to display.");
          return;
      }
      while (iter.hasNext()) {
          Customer cust = (Customer) iter.next();
          String msg = cust.getCustomerName();
          System.out.println(msg);
      }

      List qpos = session.createQuery("select c.customerName, c.city from Customer c where c.customerName=? and city=?")
      .setString(0, "Leon")
      .setString(1, "Delhi")
      .list();
      Iterator itera = query.iterator();
      if (!itera.hasNext()){
          System.out.println("No name to display.");
          return;
      }
      while (itera.hasNext()) {
          Customer cust = (Customer) itera.next();
          System.out.println("Name: "+ cust.getCustomerName()+" City: "+cust.getCity());
      }

      
      session.getTransaction().commit();
  }
    catch (Exception e) {
        System.out.println(e.getMessage());
    }
    finally {
        session.close();
    }
  }
}