package com.demo;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class NamedPara {
    private static SessionFactory sessionFactory;
    private static ServiceRegistry serviceRegistry;
    public static void main(String args[]) {
    Session session = null;
    try{
      try{
          Configuration cfg = new Configuration().configure("/com/demo/hibernate.cfg.xml");                    
          cfg.addAnnotatedClass(Customer.class);
          serviceRegistry = new ServiceRegistryBuilder().applySettings(      
                            cfg.getProperties()).buildServiceRegistry();
          sessionFactory = cfg.buildSessionFactory(serviceRegistry);
      }
      catch (Exception th) {
          System.err.println("Failed to create sessionFactory object."+ th.getMessage());
          throw new ExceptionInInitializerError(th);
      }
      session = sessionFactory.openSession();
      session.beginTransaction();
      //Named Parameters
      Query query = session.getNamedQuery("findCustomerByName");  
      query.setString("name", "levin");  
            
      List<Customer> customers=query.list();  
            
      Iterator<Customer> itr=customers.iterator();  
       while(itr.hasNext()){  
      Customer e=itr.next();  
      System.out.println(e);  
       }  
 
      session.getTransaction().commit();
  }
    catch (Exception e) {
        System.out.println(e.getMessage());
    }
    finally {
        session.close();
    }
  }
}