package com.demo;


import javax.persistence.*;  
import javax.persistence.Entity;  
import javax.persistence.Id;  
  
@NamedQueries(  
    {  
        @NamedQuery(  
        name = "findCustomerByName",  
        query = "from Customer c where c.customerName = :name"  
        )  
    }  
)  
  
@Entity
public class Customer {
	        @Id
	        private int customerId;
		private String customerName;
		private String city;
		Customer(){}
		Customer(String name){
                        this.customerName=name;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public int getCustomerId() {
			return customerId;
		}
		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		
		public String toString()	{
			return ("CustomerId "+customerId+"  CustomerName "+customerName);
		}
}