package com.demo.infytel.customer.controller;


public class UserErrorType {

    private String errorMessage;

    public UserErrorType(String errorMessage){
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

}
