package com.demo.infytel.customer;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.client.RestTemplate;

 

public class SpringBootRestTestClient {
	  
    public static final String REST_SERVICE_URI = "http://localhost:8080/api";
      
    /* GET */
    @SuppressWarnings("unchecked")
    private static void listAllUsers(){
        System.out.println("Testing listAllUsers API-----------");
          
        RestTemplate restTemplate = new RestTemplate();
        String usersMap = restTemplate.getForObject(REST_SERVICE_URI+"/books/", String.class);
           
      System.out.println(usersMap);
        }
  
      
    /* GET */
    private static void getUser(){
        System.out.println("Testing getUser API----------");
        RestTemplate restTemplate = new RestTemplate();
     String user = restTemplate.getForObject(REST_SERVICE_URI+"/books/1", String.class);
        System.out.println(user);
    }
      
    /* POST */
    private static void createUser() {
        System.out.println("Testing create User API----------");
        RestTemplate restTemplate = new RestTemplate();
     
       restTemplate.postForLocation(REST_SERVICE_URI+"/books/", "Sending this data", String.class);
        System.out.println("saved: ");
    }
  
    /* PUT */
    private static void updateUser() {
        System.out.println("Testing update User API----------");
        RestTemplate restTemplate = new RestTemplate();
    
        restTemplate.put(REST_SERVICE_URI+"/books/1", "New data");
        System.out.println("Updated");
    }
  
    /* DELETE */
    private static void deleteUser() {
        System.out.println("Testing delete User API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/books/3");
    }
  
  
    /* DELETE */
    private static void deleteAllUsers() {
        System.out.println("Testing all delete Users API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/books/");
    }
  
    public static void main(String args[]){
        listAllUsers();
        getUser();
        createUser();
        listAllUsers();
        updateUser();
        listAllUsers();
        deleteUser();
        listAllUsers();
        deleteAllUsers();
        listAllUsers();
    }
}
