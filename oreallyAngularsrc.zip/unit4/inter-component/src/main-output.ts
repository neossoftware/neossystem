import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/output/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
