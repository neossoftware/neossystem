export interface Stock {
  stockSymbol: string;
  bidPrice: number;
}
