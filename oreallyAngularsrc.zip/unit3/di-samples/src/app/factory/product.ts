export class Product {
  constructor(
    public title: string,
    public id?: number,
    public price?: number,
    public description?: string
  ) {
  }
}
