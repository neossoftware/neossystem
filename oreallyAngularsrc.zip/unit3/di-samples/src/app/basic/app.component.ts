import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h1> Basic Dependency Injection Sample</h1>
             <di-product-page></di-product-page>`
})
export class AppComponent {}
