import './polyfills.ts';

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/fromevent/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
