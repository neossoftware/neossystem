package com.infosys.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.domain.Employee;
import com.infosys.repository.EmployeeRepository;


@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {


	    @Autowired
	    private EmployeeRepository employeeRepository;  
	   
		public void insertEmployee(Employee employee) {
			
			employeeRepository.saveAndFlush(employee);
	        
	    }
		public void removeEmployee(int empId) {
			 Employee emp = employeeRepository.findOne(empId);
			 employeeRepository.delete(emp);
		}

}
