package com.demo.repository;

import com.demo.domain.Employee;

public interface EmployeeDAO {
	
	public void insertEmployee(Employee emp);

	public int removeEmployee(int empId);
}