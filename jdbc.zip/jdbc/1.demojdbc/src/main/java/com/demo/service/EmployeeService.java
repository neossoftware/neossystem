package com.demo.service;

import com.demo.domain.Employee;

public interface EmployeeService {
	
	public void insert(Employee emp);

	public int delete(int empId);

}

