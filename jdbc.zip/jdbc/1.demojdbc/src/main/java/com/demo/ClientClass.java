package com.demo;

import java.util.Scanner;

import com.demo.domain.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class ClientClass {

	public static void main(String[] args) throws Exception{
		
		
		EmployeeService service=new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		  while (true) {
				System.out.println("1: Insert new Employee\n" + "2: Delete an employee\n");
				System.out.println("Enter your choice:\n");
				int ch = sc.nextInt();
				switch (ch) {
				case 1:
					System.out.println("Enter the empId to be inserted ");
					int empId = sc.nextInt();
					System.out.println("Enter the employeename to be inserted ");
					String empName = sc.next();
					System.out.println("Enter the department to be inserted ");
					String dept = sc.next();
					Employee e1=new Employee(empId,empName,dept);
					try{
					service.insert(e1);
					}
					catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 2:
					System.out.println("Enter the empId to be deleted ");
			        int eId = sc.nextInt();
			        int result = service.delete(eId);
			        if (result > 0) {
			            System.out.println(" Record Deleted ");
			        } else {
			            System.out.println(" No record found for the given empId ");
			        }              
					break;
				/*case 3:
					System.out.println("Enter the empId to be updated ");
			        int eId1 = sc.nextInt();
			        int result1 = service.updateEmployee(eId1);
			        if (result1 > 0) {
			            System.out.println(" Record updated ");
			        } else {
			            System.out.println(" No record found for the given empId ");
			        }   
					break;
				
				case 4:
					List<Employee>elist=service.fetchEmployee();
					for (Employee employee : elist) {
						System.out.print(employee.getEmpId()+" ");
						System.out.print(" "+employee.getEmpName());
						System.out.print(" "+employee.getEmpDept());
						System.out.println();
					}
					break;
				case 5:
					sc.close();
					System.exit(1);
				default:
					System.out.println("Wrong choice enterered. Enter your choice again");
					break;
				*/}
			
			}
			

	}

}
