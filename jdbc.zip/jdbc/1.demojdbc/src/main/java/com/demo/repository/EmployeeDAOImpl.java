package com.demo.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.demo.domain.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{
	Connection con = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	// JDBC driver and database URL
	String driver = "org.h2.Driver";
	String url = "jdbc:h2:tcp://localhost/~/mydb";
	// Database credentials
	String username = "sa";
	String password = "";

	public void insertEmployee(Employee employee) {
		try {
			// Register driver
			Class.forName(driver);
			con = DriverManager.getConnection(url, username, password);
			// Create connection
			String query = "insert into employee values (?,?,?)";
			// Create prepared statement
			stmt = con.prepareStatement(query);
			stmt.setInt(1, employee.getEmpId());
			stmt.setString(3, employee.getEmpName());
			stmt.setString(2, employee.getEmpDept());
			// Execute query
			stmt.executeUpdate();
			con.commit();
			System.out.println("Record inserted");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Close the prepared statement
				stmt.close();
				// Close the connection
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// Method to remove a record from Employee table
	public int removeEmployee(int empId) {
		int result = 1;
		try {
			// Register driver
			Class.forName(driver);
			// Create connection
			con = DriverManager.getConnection(url, username, password);
			String query = "DELETE FROM Employee WHERE empid = ?";
			// Create prepared statement
			stmt = con.prepareStatement(query);
			stmt.setInt(1, empId);
			// Execute query
			result = stmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Close the prepared statement
				stmt.close();
				// Close the connection
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	/*public List<Employee> fetchEmployee() throws SQLException {
	List<Employee> emplist = new ArrayList<>();
	try {
		Class.forName(driver);
		con = DriverManager.getConnection(url, username, password);
		// "select * from sample.employee where empId= ?";

		String query = "select * from employee ";
		stmt = con.prepareStatement(query);

		rs = stmt.executeQuery(query);

		while (rs.next()) {
			Employee employee = new Employee();
			employee.setEmpId(rs.getInt(1));
			employee.setEmpName(rs.getString(2));
			employee.setEmpDept(rs.getString(3));
			emplist.add(employee);

		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		con.close();
	}
	return emplist;
}*/
	/*public int updateEmployee(int eId) {
		int result=1;
		try {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter new name");
			String name=sc.next();
			System.out.println("enter dept");
			String dept=sc.next();
			// Register driver
			Class.forName(driver);
			// Create connection
			con = DriverManager.getConnection(url, username, password);
			String query = "update Employee set empname=? , empdept=? WHERE empid = ?";
			// Create prepared statement
			stmt = con.prepareStatement(query);
			stmt.setString(1,name );
			stmt.setString(2, dept);
			stmt.setInt(3, eId);
			//System.out.println(eId+" "+name+" "+dept);
			// Execute query
			result = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Close the prepared statement
				stmt.close();
				// Close the connection
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}*/

	
}
