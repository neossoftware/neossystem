package com.demo.service;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeDAO;
import com.demo.repository.EmployeeDAOImpl;


public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDAO employeeDAO=new EmployeeDAOImpl();
	
 

	public void insert(Employee emp) {
		employeeDAO.insertEmployee(emp);
		
	}

	public int delete(int empId) {
		return employeeDAO.removeEmployee(empId);
	}
	
	

	

	

	/*public List<Employee> fetchEmployee() throws SQLException {
		return employeeRepository.fetchEmployee();
	}

	public int updateEmployee(int eId) {
		return employeeRepository.updateEmployee(eId);
	}*/
}
