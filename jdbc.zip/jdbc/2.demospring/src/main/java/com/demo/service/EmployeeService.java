package com.demo.service;

import java.util.List;

import com.demo.domain.Employee;

public interface EmployeeService {
	
	public void createEmployee(Employee emp);

	public List<Employee> selectAllEmployees();

	public int getNumberOfEmployees();

	public int deleteEmployee(int empId);

	public int updateEmployee(int empId, String department);
}
