package com.demo.repository;

import java.util.List;

import com.demo.domain.Employee;

public interface EmployeeDAO {
	
	public void createTable();
	
	public void insert(Employee emp);

	public List<Employee> getAll();

	public int getCount();

	public int delete(int empId);

	public int update(int empId, String department);
}
