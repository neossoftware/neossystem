package com.demo.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.demo.domain.Employee;

@Repository(value = "employeedao")
public class EmployeeDAOImpl implements EmployeeDAO {

	private JdbcTemplate jdbctemplate;

	@Autowired
	public void setDs(DataSource ds) {
		this.jdbctemplate = new JdbcTemplate(ds);
	}

	public void createTable() {
		String query = "create table Employee(empId integer primary key not null, empName varchar(25),empdept varchar(25))";
		jdbctemplate.execute(query);
	}

	public void insert(Employee emp) {
		String query = "INSERT INTO Employee(EmpId, EmpName, empdept) Values (?,?,?)";
		jdbctemplate.update(
				query,
				new Object[] { emp.getEmpId(), emp.getEmpName(),
						emp.getDepartment() });
	}

	public List<Employee> getAll() {
		String sql = "select empId, empName ,empdept from Employee";
		return jdbctemplate.query(sql, new RowMapper<Employee>() {
			public Employee mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				Employee emp = new Employee();
				emp.setEmpId(rs.getInt("empId"));
				emp.setEmpName(rs.getString("empName"));
				emp.setDepartment(rs.getString("empdept"));
				return emp;
			}
		});
	}
	
	public int getCount() {

		String sql = "Select count(*) from Employee";
		return jdbctemplate.queryForObject(sql, Integer.class);
	}

	public int delete(int empid) {

		return jdbctemplate.update("delete from Employee where empid = ? ",
				empid);
	}

	public int update(int empid, String department) {
		String query = "update Employee set empdept = ? "+ " where empid = ?";
		return jdbctemplate.update(query, department, empid);
	}

}
