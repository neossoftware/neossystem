
package com.infosys.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.infosys.domain.Employee;

// @Repository is used to mention that this class uses the DAO APIs
@Repository(value = "Employeedaobean")
public class EmployeeDAOImpl implements EmployeeDAO {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public void setDs(DataSource ds) {
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(ds);
	}

	// public void doExecute() {
	// namedParameterJdbcTemplate.execute("create table Employee (empId integer,
	// empName varchar(100),department varchar(100))");
	// }

	public int delete(int empid1) {
		String sql = "delete from Employee where empid = :emp_id";
		SqlParameterSource namedparam = new MapSqlParameterSource("emp_id", empid1);
		return namedParameterJdbcTemplate.update(sql, namedparam);
	}

	public int insert(Employee Employee) {
		// Use the property names as parameters - :empId ,:empName,:department
		String sql = "insert into Employee(empname,empid,department) values (:empName,:empId,:department) ";
		SqlParameterSource parameters = new BeanPropertySqlParameterSource(Employee);
		return namedParameterJdbcTemplate.update(sql, parameters);

	}

}
