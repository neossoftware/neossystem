package com.demo.domain;

public class Employee {
	private int empId;
	private String empName;
	private String empdept;

	public Employee() {
		super();
	}

	public Employee(int empId, String empName, String empdept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empdept = empdept;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

 

	public String getEmpdept() {
		return empdept;
	}

	public void setEmpdept(String empdept) {
		this.empdept = empdept;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empdept=" + empdept + "]";
	}

}
