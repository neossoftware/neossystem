package com.demo.repository;

import java.util.List;

import com.demo.domain.Employee;

public interface EmployeeDAO {
   
    
    public int delete(int empid);
    int insert(Employee Employee);
   
}
