package com.infosys.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.domain.Employee;
import com.infosys.repository.EmployeeDAOImpl;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAOImpl employeeDao;

	// Method to interact with data access layer to insert a record into
	// Employee table
	public void insertEmployee(Employee employee) {
		employeeDao.insert(employee);
	}

	// Method to interact with data access layer to remove a record from the
	// Employee table
	public int removeEmployee(int empId) {
		return employeeDao.delete(empId);
	}

	
}
