package com.demo.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.domain.Employee;
import com.demo.service.EmployeeService;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String arg[]) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Config.xml");
		EmployeeService employeeService = (EmployeeService) ctx.getBean("employeeService");

		System.out.println("Inserting records to the Table");
		System.out.println("Enter the empid to be inserted ");
		Scanner sc2 = new Scanner(System.in);
		int eid = sc2.nextInt();

		System.out.println("Enter the empname to be inserted ");
		Scanner sc3 = new Scanner(System.in);
		String name = sc3.nextLine();

		System.out.println("Enter the department to be inserted ");
		Scanner sc4 = new Scanner(System.in);
		String dept = sc4.nextLine();

		Employee e1 = new Employee();
		e1.setEmpId(eid);
		e1.setEmpName(name);
		e1.setEmpdept(dept);

		employeeService.insertEmployee(e1);
		System.out.println(" Record successfully inserted ");

		System.out.println("Enter the empid to be deleted ");
		Scanner sc = new Scanner(System.in);
		int empid = sc.nextInt();
 
		int result = employeeService.removeEmployee(empid);

		if (result > 0) {
			System.out.println(" Record Deleted ");
		} else {
			System.out.println(" No record found for the empid given ");
		}

	}

}
