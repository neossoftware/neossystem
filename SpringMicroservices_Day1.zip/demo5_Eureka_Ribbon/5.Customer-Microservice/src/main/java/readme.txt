
add the below line to application.properties in the GIT
eureka.client.service-url.defaultZone=http://localhost:5555/eureka