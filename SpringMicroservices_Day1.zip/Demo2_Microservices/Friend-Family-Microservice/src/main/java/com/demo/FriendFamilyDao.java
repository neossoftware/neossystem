package com.demo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface FriendFamilyDao extends CrudRepository<FriendFamily, Integer>{
	
	@Query("select f.friendAndFamily from FriendFamily f where f.phoneNo=:phoneNo")
	List<Long> getFriendFamilyNumbers(@Param("phoneNo") long phoneNo); 
}
