package com.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FriendFamilyController {

	@Autowired FriendFamilyDao friendDao;
	
	@RequestMapping(value="/friends/{phoneNo}")
	public List<Long> getFriendsForNumber(@PathVariable("phoneNo") long phoneNo){
		System.out.println("===Hit===");
		return friendDao.getFriendFamilyNumbers(phoneNo);
	}
		
	@RequestMapping(value="/newfriend",method=RequestMethod.POST)
	@ResponseBody
	public void saveFriend(@RequestBody FriendFamily friendFamily){
		friendDao.save(friendFamily);
	}

	
}

