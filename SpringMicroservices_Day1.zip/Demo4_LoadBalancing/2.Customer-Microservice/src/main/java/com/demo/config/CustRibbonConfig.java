package com.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.IPing;
import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.PingUrl;
import com.netflix.loadbalancer.RandomRule;

public class CustRibbonConfig {
	
	@Autowired IClientConfig clientConfig;
	
	@Bean
	public IPing changePing(IClientConfig clientConfig) {
		
		return new PingUrl();
	}
	
	@Bean
	public IRule changeRule(IClientConfig clientConfig) {
		return new RandomRule();
	}

}
