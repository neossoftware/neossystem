package com.pack.ars.exception;
@SuppressWarnings("serial")
public class FlightNotAvailableException extends Exception {


	public FlightNotAvailableException(String message) {
		super(message);
	}

}
