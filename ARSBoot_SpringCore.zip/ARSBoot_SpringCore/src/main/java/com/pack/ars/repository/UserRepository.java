package com.pack.ars.repository;

import org.springframework.stereotype.Component;

import com.pack.ars.model.User;

@Component
public class UserRepository {
	
	public String registerUser(User user)
	{
		return "UserRespository.REGISTRATION_SUCCESS";
	}
}



