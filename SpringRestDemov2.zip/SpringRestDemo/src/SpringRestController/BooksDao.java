package SpringRestController;

 

 
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

 


public enum BooksDao {
    instance;

    private ArrayList<Book> booksStore = new ArrayList<Book>();

    private BooksDao() {
 
 
        Book b = new Book("1", "RESTful Web Services");
       
        booksStore.add(b);
        b = new Book("2", "RESTful Java with JAX-RS");
 
        booksStore.add( b);
        
       
    }
    public List<Book> getBooksStore(){
        return booksStore;
    }

}