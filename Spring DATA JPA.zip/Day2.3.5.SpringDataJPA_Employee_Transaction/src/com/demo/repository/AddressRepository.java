package com.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import com.demo.domain.Employee;
public interface AddressRepository extends JpaRepository<Employee, Integer> {
@Modifying(clearAutomatically = true)
@Transactional 
@Query(value="update address12 set city = ?, pincode=? where addressId = ?", nativeQuery=true)
public int updateAddress(String city, String pincode, int addressId);  }
