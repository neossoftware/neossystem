package com.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import com.demo.domain.Employee;
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
@Modifying(clearAutomatically = true)
@Transactional 
@Query(value="update Employee12   set baseLocation = ? where empId = ?", nativeQuery=true)
public int updateEmployee(String baseLocation, int empId);
}
 