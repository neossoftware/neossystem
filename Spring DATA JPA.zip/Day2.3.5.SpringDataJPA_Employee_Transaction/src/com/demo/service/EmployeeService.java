
package com.demo.service;
import com.demo.domain.Employee;
public interface EmployeeService {
// Method update employee details such as address and base location
void updateEmployeeDetails(Employee emp);
void insertEmployee(Employee employee);
}
