package com.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.domain.Employee;
import com.demo.repository.AddressRepository;
import com.demo.repository.EmployeeRepository;
@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
@Autowired
private EmployeeRepository employeeRepository;
@Autowired
private AddressRepository addressRepository;
public void insertEmployee(Employee employee){
employeeRepository.save(employee);
}
@Override
public void updateEmployeeDetails(Employee emp) {
//Method to update new base location in Employee table and address in address table
	System.out.println(emp);
	
	int r=employeeRepository.updateEmployee(emp.getBaseLocation(),emp.getEmpId());
int m=addressRepository.updateAddress(emp.getAddress().getCity(),emp.getAddress().getPincode(),emp.getAddress().getAddressId());
System.out.println(r+""+m);
}
}
