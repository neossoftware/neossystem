package com.demo.domain;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity(name="Employee12")
public class Employee{
@Id
private int empId;
private String empName;
private String department;
private String baseLocation;
@OneToOne(cascade=CascadeType.ALL)
@JoinColumn
Address address;
public Employee(int empId, String empName, String department, String baseLocation, Address address) {
super();
this.empId = empId;
this.empName = empName;
this.department = department;
this.baseLocation = baseLocation;
this.address = address;
}
public Employee() {
super();
}
public int getEmpId() {
return empId;
}
public void setEmpId(int empId) {
this.empId = empId;
}
public String getEmployeeName() {
return empName;
}
public void setEmpName(String empName) {
this.empName = empName;
}
public String getDepartment() {
return department;
}
public void setDepartment(String department) {
this.department = department;
}
public String getBaseLocation() {
return baseLocation;
}
public void setBaseLocation(String baseLocation) {
this.baseLocation = baseLocation;
}
public Address getAddress() {
return address;
}
public void setAddress(Address address) {
this.address = address;
}
@Override
public String toString() {
return "Employee [empId=" + empId + ", empName=" + empName + ", department=" + department
+ ", baseLocation=" + baseLocation + ", address=" + address + "]";
}

}
