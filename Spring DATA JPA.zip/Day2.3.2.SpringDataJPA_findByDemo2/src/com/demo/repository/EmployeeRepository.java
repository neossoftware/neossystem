package com.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.domain.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	List<Employee> findByLastNameLike(String lastname);

	List<Employee> findByDeptOrDept(String dept1, String dept2);

	List<Employee> findByFirstNameAndDept(String firstname, String dept);

	public Iterable<Employee> getByLastNameLike(String kumar);

	Employee findByEmailAddress(String string);

	Iterable<Employee> findByLastNameOrFirstName(String string, String string2);
	
	

}
