package com.demo.service;

import java.util.List;

import com.demo.domain.Employee;

public interface EmployeeService {

	public void insertEmployee(Employee employee) ;
	List<Employee> findByLastNameLike(String lastname);
	List<Employee>  findByDeptOrDept(String dept1,String dept2);
	  List<Employee>  findByFirstNameAndDept(String firstname,String dept);

	    public Iterable<Employee> getByLastNameLike(String kumar);
}
