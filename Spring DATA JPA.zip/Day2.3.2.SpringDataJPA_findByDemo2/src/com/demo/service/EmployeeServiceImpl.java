package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeRepository;


@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {


	    @Autowired
	    private EmployeeRepository employeeRepository;  
	   
		public void insertEmployee(Employee employee) {
			
			employeeRepository.saveAndFlush(employee);
	        
	    }

		public List<Employee> findByLastNameLike(String lastname) {
			// TODO Auto-generated method stub
			return employeeRepository.findByLastNameLike(lastname);
			
		}

		public List<Employee> findByDeptOrDept(String dept1, String dept2) {
			// TODO Auto-generated method stub
			 return employeeRepository.findByDeptOrDept(dept1, dept2);
			
		}

		public List<Employee> findByFirstNameAndDept(String firstname, String dept) {
			// TODO Auto-generated method stub
			return employeeRepository.findByFirstNameAndDept(firstname, dept);
		}

		public Iterable<Employee> getByLastNameLike(String kumar) {
			// TODO Auto-generated method stub
			return employeeRepository.getByLastNameLike(kumar);
		}
		

}
