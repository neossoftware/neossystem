package com.demo.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeRepository;
import com.demo.service.EmployeeService;


public class EmployeeTest {

  

    public static void main(String[] args) {
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
        EmployeeService service = context.getBean(EmployeeService.class);
        Employee emp1 = new Employee(22, "Arun", "Kumar", "IVS", "abc@xyz.com");
        Employee emp2 = new Employee(23, "Ashwin", "Kumar", "HR", "aaa@gmail.com");
        Employee emp3 = new Employee(24, "Bob", "sinha", "IVS", "bana@xyz.com");
        service.insertEmployee(emp1);
        service.insertEmployee(emp2);
        service.insertEmployee(emp3);

        Iterable<Employee> emp = service.findByLastNameLike("Kumar");

        System.out.println("find by last name like Kumar");
        for (Employee alist : emp) {
            System.out.println(alist);
        }
         System.out.println("Get by first name ends with");
                Iterable<Employee> elist1 = service.getByLastNameLike("Kumar");
                for(Employee alist2 : elist1){
                      System.out.println(alist2);
                }       
        System.out.println("Find by email address");
        EmployeeRepository repository=context.getBean(EmployeeRepository.class);
        Employee emp5 =repository.findByEmailAddress("aaa@xyz.com");
        System.out.println(emp5);

        System.out.println("Find by last or first name");

        Iterable<Employee> emp6 =(Iterable<Employee>) repository.findByLastNameOrFirstName("Kumar", "Bana das");
        for(Employee alist3 : emp6){
             System.out.println(alist3);
        }
         System.out.println("Find by first name ends with");

         System.out.println("*********** List of Educators ************");

        Iterable<Employee> elist =repository.findAll();
        for(Employee alist1 : elist){
        System.out.println(alist1);
        }

        System.out.println("find based on department");
        Iterable<Employee> elist2 = service.findByDeptOrDept("IVS", "HR");
        for (Employee alist3 : elist2) {
            System.out.println(alist3);
        }
        System.out.println("find based on first name and department");
        Iterable<Employee> elist3 = service.findByFirstNameAndDept("Arun", "IVS");
        for (Employee alist4 : elist3) {
            System.out.println(alist4);
        }
        context.close();
    }
    


}
