package com.demo.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.domain.Employee;
import com.demo.service.EmployeeService;

public class EmployeeTest {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		EmployeeService service = (EmployeeService) context.getBean("employeeService");
		Employee emp1 = new Employee(22, "Arun", "Kumar", "Engineering", "abc@xyz.com");
		Employee emp2 = new Employee(23, "Ashwin", "Kumar", "IVS", "aaa@gmail.com");
		Employee emp3 = new Employee(24, "Bob", "sinha", "IVS", "bana@xyz.com");
		service.insertEmployee(emp1);
		service.insertEmployee(emp2);
		service.insertEmployee(emp3);

		Iterable<Employee> emp = service.getEmployee("IVS");

		for (Employee alist : emp) {
			System.out.println(alist);
		}
		context.close();
	}

}
