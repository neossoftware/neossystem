package com.demo.service;

import com.demo.domain.Employee;

public interface EmployeeService {

	public void insertEmployee(Employee employee);

	public Iterable<Employee> getEmployee(String depId);
}
