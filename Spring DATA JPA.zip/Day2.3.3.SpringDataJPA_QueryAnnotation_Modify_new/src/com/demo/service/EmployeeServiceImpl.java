package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeRepository;


@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {


	    @Autowired
	    private EmployeeRepository employeeRepository;  
	   
		public void insertEmployee(Employee employee) {
			
			employeeRepository.saveAndFlush(employee);
	        
	    }

		public void insert() {
			employeeRepository.insert();
			// TODO Auto-generated method stub
			
		}

		public void emailUpdate(String emailAddress, int id) {
			// TODO Auto-generated method stub
			employeeRepository.emailUpdate(emailAddress, id);;
			
		}

		
}
