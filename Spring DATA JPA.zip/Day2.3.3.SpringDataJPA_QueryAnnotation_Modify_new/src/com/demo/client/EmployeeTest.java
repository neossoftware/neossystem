package com.demo.client;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeRepository;


public class EmployeeTest {

  

    public static void main(String[] args) {
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
        EmployeeRepository repository = context.getBean(EmployeeRepository.class);
               
      repository.insert();
      
       System.out.println("update email address");
       
     repository.emailUpdate("aaa@gmail.com", 1002);
 
    context.close();
    }

}
