package com.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.demo.domain.Employee;



public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	 @Transactional 
	   /* clearAutomatically = true is to clear entity manager automatically, drop all pending changes
	   that have not been flushed to database yet. This attribute should be used carefully otherwise will lose any pending
	   changes*/
	   @Modifying(clearAutomatically = true)
	   @Query(value="INSERT into Employee8(id,firstName,lastName,dept,emailaddress) values (1003,'Alex','Bob','java','alex@gmail.com')", nativeQuery = true)
	   void insert();        
	   
	   @Transactional
	   @Modifying
	   @Query(value = "update  Employee8 set emailAddress = ? " + " where id = ?", nativeQuery = true)
	   void emailUpdate(String emailAddress,int id);
	     



}
