package com.demo.client;

import java.util.Scanner;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.domain.Employee;
import com.demo.service.EmployeeService;

public class EmployeeTest {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		EmployeeService service = (EmployeeService) context.getBean("employeeService");

		// Create Employee instances
		Employee emp1 = new Employee(1001, "Smith", "Engineering");
		Employee emp2 = new Employee(1002, "Alex", "Account");

		// Invoking Service layer method to insert Employee details into
		// Employee table
		service.insertEmployee(emp1);
		service.insertEmployee(emp2);

		System.out.println("Enter the employee id to be deleted");
		Scanner scanner = new Scanner(System.in);
		int empId = scanner.nextInt();

		// Invoking Service layer method to remove Employee details from
		// Employee table
		service.removeEmployee(empId);

		scanner.close();
		context.close();

	}
}
