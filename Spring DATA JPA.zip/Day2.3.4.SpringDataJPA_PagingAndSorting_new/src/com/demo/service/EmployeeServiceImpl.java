package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeRepository;


@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {


	    @Autowired
	    private EmployeeRepository employeeRepository;  
	   
		public void insertEmployee(Employee employee) {
			
			employeeRepository.saveAndFlush(employee);
	        
	    }

		public Page<Employee> findAll(Pageable page) {
			return employeeRepository.findAll(page);
		}
		public  List<Employee> findAll(Sort sort) {
			return employeeRepository.findAll(sort);
		}
		 
}
