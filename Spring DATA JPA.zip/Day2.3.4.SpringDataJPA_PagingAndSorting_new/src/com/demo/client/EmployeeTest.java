package com.demo.client;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeRepository;
import com.demo.service.EmployeeService;


public class EmployeeTest {

  

    public static void main(String[] args) {
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
        EmployeeService service = context.getBean(EmployeeService.class);
        Employee emp1=new Employee(22, "Arun", "Kumar", "Engineering","abc@xyz.com");
        Employee emp2=new Employee(23, "Ashwin", "Kumar", "Imaginea", "aaa@gmail.com");
        Employee emp3=new Employee(24, "Bob", "John", "HR","bob@xyz.com");          
        Employee emp4=new Employee(25, "Aravind", "sen", "ENG","ara@xyz.com"); 
        Employee emp5=new Employee(26, "Smitha", "sen", "ENG","bana@xyz.com");  
        
        service.insertEmployee(emp1);
        service.insertEmployee(emp2);
        service.insertEmployee(emp3);
        service.insertEmployee(emp4);
        service.insertEmployee(emp5);
          
             
        EmployeeRepository repository = context.getBean(EmployeeRepository.class);  
        Iterable<Employee> emp6 =(Iterable<Employee>) repository.findAll();
        
        for(Employee alist3 : emp6){
             System.out.println(alist3);
        }
        
        Pageable pageable = PageRequest.of(1,4);
        
        System.out.println("Records are: ");
        Iterable<Employee> emp7 =(Iterable<Employee>) service.findAll(pageable);
        
        for(Employee alist3 : emp7){
             System.out.println(alist3);
        }
       
        System.out.println("Sorted records..");
        Sort sort = new Sort(Sort.Direction.ASC, "firstName");
        
        Iterable<Employee> emp8 =(Iterable<Employee>) service.findAll(sort);
        
        for(Employee alist3 : emp8){
             System.out.println(alist3);
        }
       
               
        context.close();
        }
}
