package com.demo.service;

import java.util.List;

import com.demo.domain.Employee;

public interface EmployeeService {

	public void insertEmployee(Employee employee);

	List<Employee> searchEmployee(String fName, String lName, String number, String email, String department);
}
