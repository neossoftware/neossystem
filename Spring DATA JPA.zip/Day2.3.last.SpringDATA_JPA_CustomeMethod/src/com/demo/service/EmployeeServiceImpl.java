package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.domain.Employee;
import com.demo.repository.EmployeeRepository;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public void insertEmployee(Employee employee) {

		employeeRepository.saveAndFlush(employee);

	}

	@Override
	public List<Employee> searchEmployee(String fName, String lName, String number, String email, String department) {

		return employeeRepository.searchEmployee(fName, lName, number, email, department);
	}

}
