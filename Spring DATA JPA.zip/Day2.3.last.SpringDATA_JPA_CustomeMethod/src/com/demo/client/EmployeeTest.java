package com.demo.client;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.domain.Employee;
import com.demo.service.EmployeeService;

public class EmployeeTest {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		EmployeeService service = (EmployeeService) context.getBean("employeeService");

		Employee emp1 = new Employee(22, "Arun", "kumar", "IVS", "1111111", "abc@xyz.com");
		Employee emp2 = new Employee(23, "Susan", "Bob", "IVS", "222222", "xyz@gmail.com");
		Employee emp3 = new Employee(24, "Sam", "John", "HR", "33333", "aaa@xyz.com");

		service.insertEmployee(emp1);
		service.insertEmployee(emp2);
		service.insertEmployee(emp3);

		List<Employee> employees1 = service.searchEmployee(null, null, "1111111", null, null);
		System.out.println(employees1);
		
		List<Employee> employees2 = service.searchEmployee("Arun", "kumar", null, null, null);
		System.out.println(employees2);
		
		List<Employee> employees3 = service.searchEmployee(null, null,null, "abc@xyz.com",null);
		System.out.println(employees3);
		
		List<Employee> employees4= service.searchEmployee(null, null,null,null,"IVS");
		System.out.println(employees4);
		context.close();

	}
}
