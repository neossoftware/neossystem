package com.demo.repository;

import java.util.List;

import com.demo.domain.Employee;

public interface IEmployeeRepository {
	public List<Employee> searchEmployee(String fName, String lName, String number, String email,String department);
		
}
