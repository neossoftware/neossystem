/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demo.domain.Employee;

@Repository
public class EmployeeRepositoryImpl implements IEmployeeRepository {

	private EntityManagerFactory emf;

	@Autowired
	public void setEntityManagerFactory(EntityManagerFactory emf) {
		this.emf = emf;
	}

	public List<Employee> searchEmployee(String fName, String lName, String number, String email,String department) {
		
		EntityManager em = emf.createEntityManager();
		CriteriaBuilder builder = em.getCriteriaBuilder();
		
		CriteriaQuery<Employee> query = builder.createQuery(Employee.class);
		Root<Employee> root = query.from(Employee.class);

		Predicate firstName = builder.equal(root.get("firstName"), fName);
		Predicate lastName = builder.equal(root.get("lastName"), lName);
		
		Predicate exp1 = builder.and(firstName, lastName);
		
		Predicate phoneNumber = builder.equal(root.get("phoneNumber"), number);
		Predicate emailId = builder.equal(root.get("email"), email);
		
		Predicate exp2 = builder.or(phoneNumber,emailId);
				
		Predicate dept = builder.equal(root.get("dept"), department);
		
		

		query.where(builder.or(exp1, exp2,dept));

		return em.createQuery(query.select(root)).getResultList();
	}

}
