package com.infosys.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infosys.domain.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	public void setEntityManagerFactory (EntityManagerFactory entityManagerFactory) {
		this.entityManagerFactory = entityManagerFactory;
	}

	public List<Employee> getAll() {
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();
		Query query = (Query) entityManager.createQuery("Select e from Employee e");
		List<Employee> empList = query.getResultList();
		return empList;
	}

	public void update(int empId, String department) {
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Employee emp = (Employee) entityManager.find(Employee.class, empId);
		emp.setDepartment(department);
		entityManager.getTransaction().commit();
		
	}
}
