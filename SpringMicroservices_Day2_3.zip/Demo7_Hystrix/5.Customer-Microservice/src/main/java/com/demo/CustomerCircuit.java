package com.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class CustomerCircuit {

	@Autowired RestTemplate template;
	
	@HystrixCommand(commandProperties= {
			@HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "50000"),
		    @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "50000"),
	},fallbackMethod="emptyFriends")
	public List<Long> getFriends(Long phoneNo){	
		System.out.println("Inside get friends");
		List<Long> numbers= template.getForObject("http://FriendMS/friends/"+phoneNo, List.class);
		System.out.println(numbers);
		return numbers;
	}
	
	public List<Long> emptyFriends(Long phoneNo){
		System.out.println("Inside empty friends");
		ArrayList l= new ArrayList();
		l.add(11111L);
		l.add(2222L);
		return l;
	}
	
	@HystrixCommand(commandProperties= {
			@HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "50000"),
		    @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "5000"),
	},fallbackMethod="dummyFallBack")
	public void dummyCall(){	
		System.out.println("Dummy call");
		System.out.println("Dummy Sleeping for 10 secs");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void dummyFallBack(){
		System.out.println("Inside fallback dummy");
	}
	
}
