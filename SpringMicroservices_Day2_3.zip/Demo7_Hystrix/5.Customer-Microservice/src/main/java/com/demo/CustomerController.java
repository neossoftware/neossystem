package com.demo;

import java.net.URI;
import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.netflix.ribbon.ServerIntrospector;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.demo.ribbonconfig.CustRibbonConfig;

@RestController
@EnableAutoConfiguration
@RefreshScope
//hystrix
@EnableCircuitBreaker
@RibbonClient(name="cust-ribbon",configuration=CustRibbonConfig.class)
public class CustomerController {
	@Autowired RestTemplate template;
	
	@Autowired CustomerDao customerDao;

	
	@Autowired CustomerCircuit circuit;
	
	@RequestMapping(value="/customers")
	public List<Customer> getAllCustomers(){
		return customerDao.findAll();
	}

	@RequestMapping(value="/customers/{phoneNo}")
	public CustomerDTO getCustomerByPhoneNo(@PathVariable Long phoneNo){

		System.out.println("Overall request started");
		long start0 = System.currentTimeMillis();
		
		
		System.out.println("==== Customer phone number is ==== "+phoneNo);
		CustomerDTO customerDto = new CustomerDTO();
		Customer c=customerDao.getCustomerByPhoneNo(phoneNo);
		customerDto.setAge(c.getAge());
		customerDto.setGender(c.getGender());
		customerDto.setName(c.getName());
		customerDto.setCustomerId(c.getCustomerId());
		customerDto.setPhoneNo(c.getPhoneNo());
		
		
		System.out.println("Request to Friends started");
		long start = System.currentTimeMillis();
		
	 
		
		List<Long> friends=circuit.getFriends(phoneNo);
		
		
		
		
		
		System.out.println("Request to Friends over");
		long stop = System.currentTimeMillis();
		System.out.println("Total time is ==="+(stop-start));
		
		System.out.println("Request to dummy started");
		long start2 = System.currentTimeMillis();
		circuit.dummyCall();
		System.out.println("Request to dummy over");
		long stop2 = System.currentTimeMillis();
		System.out.println("Total time is ==="+(stop2-start2));

		System.out.println("Friends from circuit "+friends);
		customerDto.setFriendAndFamily(friends);
		
		System.out.println("Overall request over");
		long stop0 = System.currentTimeMillis();
		System.out.println("Total time is ==="+(stop0-start0));
		return customerDto;

	}






	@RequestMapping(value="/newcustomer",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void newCustomer(@RequestBody Customer customer){
		customerDao.save(customer);
	}

}
