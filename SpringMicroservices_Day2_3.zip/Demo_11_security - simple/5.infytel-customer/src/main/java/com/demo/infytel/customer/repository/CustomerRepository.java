package com.demo.infytel.customer.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.infytel.customer.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

	Customer findByPhoneNo(Long phoneNo);

}
