package com.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.netflix.hystrix.contrib.javanica.command.AsyncResult;

@Service
public class CustomerCircuit {

	@Autowired RestTemplate template;
	@Autowired CustFeignInterface custFeign;
	
	@HystrixCommand(commandProperties= {
			@HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "50000"),
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "50000"),
	},fallbackMethod="emptyFriends")

	public Future<List<Long>> getFriends(Long phoneNo) {
		return new AsyncResult<List<Long>>() {

			@Override
			public List<Long> invoke(){
				System.out.println("Inside get friends");
				List<Long> numbers= custFeign.getFriends(phoneNo);
				System.out.println("Numbers in circuit "+numbers);
				return numbers;
			}
		};

	}


	public List<Long> emptyFriends(Long phoneNo)throws InterruptedException{
		System.out.println("Inside empty friends");
		return new ArrayList<Long>();
	}


	@HystrixCommand(commandProperties= {
			@HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "50000"),
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "50000"),
	},fallbackMethod="dummyFallBack")
	public Future<String> dummyCall(){	
		return new AsyncResult<String>() {

			@Override
			public String invoke(){
				System.out.println("Dummy call");
				System.out.println("Dummy Sleeping for 10 secs");
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return "Hello";
			}
		};
	}

			public String dummyFallBack(){
				System.out.println("Inside fallback dummy");
				return "Hello dummy";
			}

		}
