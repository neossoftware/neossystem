package mypack;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="/hello1.htm")
public class MyController {
		
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView sayGreeting(){
		String msg="Hi, Welcome to Spring MVC 3.0";
		System.out.println("In GET Handler method of MyController");
			return new ModelAndView("/WEB-INF/jsp/success.jsp","m",msg);
	} 
	@RequestMapping(method=RequestMethod.POST)
	public String getDetails(@RequestParam("name") String uname,@RequestParam("pwd") String pswd,ModelMap m){
		m.addAttribute("name1", uname);
			m.addAttribute("pwd1",pswd);
			System.out.println("In POST Handler method of MyController");
		return "/WEB-INF/jsp/myview.jsp";
	}
	

	
	}
	
	
	
	
	
	


