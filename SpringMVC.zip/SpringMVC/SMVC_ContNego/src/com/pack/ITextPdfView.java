package com.pack;

import java.text.DateFormat;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class ITextPdfView extends AbstractITextPdfView {
	private static final DateFormat DATE_FORMAT = DateFormat.getDateInstance(DateFormat.SHORT);

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		PdfPTable table = new PdfPTable(4);
		table.setWidths(new int[] { 50, 50, 50, 50});
		table.addCell("Student Name:");
		table.addCell("Student Hobby:");
		table.addCell("Student Mobile: ");
		table.addCell("Student DOB: ");
		table.addCell(String.valueOf(model.get("studentName")));
		table.addCell(String.valueOf(model.get("studentHobby")));
		table.addCell(String.valueOf(model.get("studentMobile")));
		table.addCell(String.valueOf(model.get("studentDOB")));
		document.add(table);
	}
}