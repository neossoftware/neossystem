package mypack;

// if it is redirect from the previous 
//controller then final.jsp wont display any value 
//from ModalMap set in RegistrationController but if 
//it is forward then the values from ModalMap set it RegistrationController
// will be displayed in final.jsp
//

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UpdateController {

	@RequestMapping(value="/update.htm")
	public String update(){
		// perform some more logic and pass to JSP 
		return "final";
	}
}
