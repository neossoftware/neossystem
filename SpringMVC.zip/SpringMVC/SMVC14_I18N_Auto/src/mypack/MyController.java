package mypack;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/login.htm")
public class MyController {
	@RequestMapping(method = RequestMethod.GET)
	public String showForm(ModelMap m){
		User user=new User();
		m.addAttribute("user", user);
		return "/WEB-INF/jsp/login.jsp";
	}
	@RequestMapping(method = RequestMethod.POST)
	public String onSubmit(@ModelAttribute("user") User user){
		//call to service layer to do login validation..
		return "/WEB-INF/jsp/success.jsp";
	}
}
