package mypack;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class MyValidator implements Validator {
	@Override
	public boolean supports(Class<?> arg0) {
		if(User.class.equals(arg0)){
			return true;		}
		return false;
	}
	@Override
	public void validate(Object arg0,Errors errors) {
		User u=(User)arg0;
		if(u.getName().equals("")){
			String[] args=new String[1];
			args[0]="User Name";
			errors.rejectValue("name", "inp.required",args,"User name  is required");
						}
		if(u.getPwd().equals("")){
			String[] args=new String[1];
			args[0]="Password";
			errors.rejectValue("pwd", "inp1.required",args,"Password is required");
			
		}
	}

}
