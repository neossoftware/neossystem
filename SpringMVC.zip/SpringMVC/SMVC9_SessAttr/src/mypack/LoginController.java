package mypack;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller
@SessionAttributes("User")
@RequestMapping("/login.htm")
public class LoginController {
	
	@RequestMapping(method=RequestMethod.GET)
	public String showForm(ModelMap map){
		User user=new User();
		map.addAttribute("User", user);
              
		return "/WEB-INF/jsp/login.jsp";
	}
        
       
	@RequestMapping(method=RequestMethod.POST)
	public String processForm(@ModelAttribute("User")User user){
		if(user.getUserName().equals("admin")&&user.getPassword().equals("admin")){

                    return "/WEB-INF/jsp/success.jsp";
		}
		return "/WEB-INF/jsp/failure.jsp";
	}
}
