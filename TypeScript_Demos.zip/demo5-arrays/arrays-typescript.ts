//This program shows the push, pop & splice of elements in an Array

let manufacturers: string[] = ["Samsung", "Motorola", "Apple", "Sony"];
let products: Array<string> = ["Smart phone", "Laptop", "Tablet", "Camaras"];

console.log("Available Manufacturers are: ");

 for (let i = 0; i < manufacturers.length; i++) {

    console.log(manufacturers[i]);

 }

console.log("Available Products are: ");

 for (let i = 0; i < products.length; i++) {

    console.log(products[i]);

 }

//Un-comment the particular code snippet to see the working  process 

//PUSH() - To add a dynamic value to an array
/*
console.log("manufacturer Lenovo added");

manufacturers.push("Lenovo");

console.log(manufacturers);
*/

//POP() - To remove the recent value from an array
/*
console.log("removed the last added manufacturer");

manufacturers.pop();

console.log(manufacturers);
*/

//SPLICE() - removes the item from a specific index position.
/*
console.log("removed the manufacturer in the specified index");

manufacturers.splice(1,2);

console.log(manufacturers);
*/