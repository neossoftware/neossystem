
console.log("Hello welcome to TypeScript");

/*
    Steps to configure Transpilation
    npm install -g typescript
    tsc hello-typescript.ts
    node hello-typescript.js
*/