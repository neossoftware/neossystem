/*  Inheritance is the process of extending a class from already existing class 
    and reuse the functions and properties of the inherited class in the sub class.
*/

class Product {
    protected productId: number;
    constructor(productId: number) {
        this.productId = productId;
    }
    getProduct(): void {
        console.log("ProductID " + this.productId);
    }
}
class Gadget extends Product {
    constructor(public productName: string, productId: number) {
        super(productId);
    }

//Overriding is a method in which the child class will have same function name as the parent class function

    getProduct(): void {
        super.getProduct();
        console.log("ProductID " + this.productId + " Product Name " + this.productName);
    }
}
var gadget = new Gadget("Tablet", 1234);
gadget.getProduct();
