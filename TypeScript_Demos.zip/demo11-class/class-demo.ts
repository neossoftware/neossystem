//class is a template from which objects can be created

class Product {

	productId: number;

	constructor(productId: number, public productName: string) {  // Only one constructor per class can be created.
		this.productId = productId;
	}

	getProduct(): string {
		return "product id is " + this.productId + " and name is " + this.productName;
	}
}


var product: Product = new Product(1234, "Lenovo K6 Power");

console.log(product.getProduct());
