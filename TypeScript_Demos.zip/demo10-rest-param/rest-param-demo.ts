/*
    Rest Parameter is used to pass multiple values to a single parameter of a function. 
    It accepts zero or more values for a single parameter
*/

let cart: string[] = [];

let pushtoCart = (productName: string) => { cart.push(productName); }

 /*
    Precede the parameter to be made as rest parameter with triple dots
    Rest Parameter should be declared as an array
    Rest parameter should be the last parameter in the function parameter list.
*/

function addtoCart(...productName: string[]): void { 
    for (let i = 0; i < productName.length; i++) {
        pushtoCart(productName[i]);
    }
}
addtoCart("Moto G Play, 4th Gen", "Apple iPhone 5s"); // We can pass number of values or even leave it empty

console.log(cart);