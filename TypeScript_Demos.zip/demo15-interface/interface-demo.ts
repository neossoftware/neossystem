/*
    Interfaces are used to enforce consistency across multiple TypeScript classes.
    Classes that implement an interface must implement all of the required members.
*/

interface Product {
    getProductDetails(): string[];
    displayProductName: (prouctId: number) => string;
}

class Gadget implements Product {
    getProductDetails(): string[] {
        return ["Samsung", "LG", "Moto"];
    }
    displayProductName(productId: number): string {
        if (productId == 101)
            return "Product Name is Mobile";
        else if (productId == 201)
            return "Product Name is Tablet";
    }
    getGadget(): string[] {
        return ["Mobile", "Tablet", "iPad", "iPod"];
    }
}
let gadget: Product = new Gadget();
let productName: string = gadget.displayProductName(101);
console.log(productName);
let productDetails: string[] = gadget.getProductDetails();
console.log("The available products are " + gadget.getProductDetails());
