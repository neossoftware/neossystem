class Product {
    private productId: number;             //Accessible only to methods inside the class
    public productName: string;            //Accessible to methods outside the class
    static productPrice: number = 15000;   //Static variables are initialized only once, at the start of the execution.
    protected productCategory: string;     //Accessible to methods inside the class as well as within inherited classes

    constructor(productId: number, productName, productCategory) {
        this.productId = productId;
        this.productName = productName;
        this.productCategory = productCategory;
    }

    getProductId() {
        console.log("The productId is " + this.productId);
        //Type: "this." and you'll be suggested with all the data members & member functions that are accessible
    }

    static discount(){  ////A static function can access only static variables and other static functions
        let dis:number = 10/100;
        let amt:number;
        dis = this.productPrice * dis;
        amt = this.productPrice - dis;
        console.log("The discounted amount is: " + amt);
    }

}


class Gadget extends Product {
    getProduct(): void {
        console.log("ProductCategory: " + this.productCategory);
        //Type: "this." and you'll be suggested with all the data members & member functions that are accessible

    }
}

var gadget: Gadget = new Gadget(1234, "Mobile", "SmartPhone");

gadget.getProduct();
gadget.getProductId();
Product.discount();  

console.log("ProductName is " + gadget.productName);
console.log("Product price is: " + Product.productPrice);
