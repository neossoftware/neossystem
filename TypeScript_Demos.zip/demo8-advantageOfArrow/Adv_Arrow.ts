// Un-comment the code snippets and execute to see the difference

class Product{
    productName :string="Mobile";
    getProductDetails(){
       console.log("Product:" +this.productName);  // 'this.productName' is under the 
    }

    testThisFunction(){
        setTimeout(function(){
            console.log("After timeout: "+this.productName); // 'this.productName' is under the current function scope. Hence we cannot access productName
        },10);
    }
}

var prod = new Product();
prod.getProductDetails();
prod.testThisFunction();


/*
class Product1{
    productName :string="Mobile";
    getProductDetails(){
        console.log("Product:" +this.productName);
    }

    testThisFunction(){
        setTimeout(
            ()=>{console.log("After timeout: "+this.productName);  //Arrow function does not create a new scope
        },10);
    }
}
var prod1 = new Product1();
prod1.getProductDetails();
prod1.testThisFunction();
*/
