//Declaration of variables in TypeScript is similar to JavaScript variable declaration. 
//Declaring variables with basic types

 // var productId = 1045;  
 /* 
    Even var can be used but using let is preffered in typescript
    
    The scope of a let declared variable is only with in the block in which it is been declared.

    The var declared variable can be accessible outside the block with in a function or class 
    in which the block is defined.
*/

// {
 let productId:number = 1045; //Declaring a numeric variable
// }
 let productDescription:string="16GB, Gold"; //Declaring a string variable
 
 var productName:string="Samsung Galaxy J7"; 
 
 let productAvailable: boolean = true;   //Declaring a boolean variable
 
 console.log("The type of productId is " + typeof productId);
 
 console.log("The type of productAvailable is "+typeof productAvailable);
 
 console.log("The type of productName is "+typeof productName);
 
 //Declaring variables using const
 
 const discountPercentage:number=15;
 
 //discountPercentage = 10;          //error due to assignment of value for constant

 console.log("Discount percentage is:"+discountPercentage);