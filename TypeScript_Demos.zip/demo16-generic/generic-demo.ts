class ArrayAppender<T> {
    
    myArray: T[] = [];

    addObject(obj: T) {
        this.myArray.push(obj);
    }

}

function display<T>(arg: T[]){
    for (var key in arg) {
        console.log(key + " : " + arg[key])
    }
}

let stringAppender: ArrayAppender<string> = new ArrayAppender<string>();

stringAppender.addObject("mobile");
stringAppender.addObject("laptop");
stringAppender.addObject("tablet");
display<string>(stringAppender.myArray);
display(stringAppender.myArray);

let numberAppender: ArrayAppender<number> = new ArrayAppender<number>();

numberAppender.addObject(12);
numberAppender.addObject(10);
display(numberAppender.myArray);