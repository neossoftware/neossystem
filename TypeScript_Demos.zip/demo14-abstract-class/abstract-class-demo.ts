//Abstract classes are base classes that may not be instantiated

abstract class Product {  //Abstract class can be created using abstract keyword
	getFeatures(): void {

	}
	//Abstract methods with in an abstract class are methods declared with abstract keyword and does not contain implementation
	abstract getProductName(): string;  
}
class Gadget extends Product {
	getProductName(): string {         //They must be implemented inside the derived classes
		return "ProductName is Mobile";
	}
}
class Clothing extends Product {
	getProductName(): string {
		return "ProductName is Shirt";
	}
}
var gadget = new Gadget();
console.log(gadget.getProductName());
var clothing = new Clothing();
console.log(clothing.getProductName());
