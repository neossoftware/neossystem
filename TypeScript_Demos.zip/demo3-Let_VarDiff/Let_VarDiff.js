console.log("The values WHEN LET is used are: ");
var _loop_1 = function (i_1) {
    setTimeout(function () { console.log(i_1); }, 100 * i_1);
};
for (var i_1 = 1; i_1 <= 10; i_1++) {
    _loop_1(i_1);
}
console.log("The values WHEN VAR is used are: ");
for (var i = 1; i <= 10; i++) {
    setTimeout(function () { console.log(i); }, 100 * i);
}
