/*
    Understanding difference between LET & VAR
    Un comment the corresponding code snippet & execute them to see the difference
*/

//Variable declared using let keyword will have block scope.

console.log("The values WHEN LET is used are: ")
for(let i=1; i<=10; i++){
    setTimeout(function() {console.log(i);},100*i);
}


//Variable declared using var keyword will have function scope.

/*
console.log("The values WHEN VAR is used are: ")
for(var i=1; i<=10; i++){
    setTimeout(function() {console.log(i);},100*i);
}

*/