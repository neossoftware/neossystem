//Optional parameter is used to make a parameter, optional in a function while invoking the function.

function getMobileByManufacturer(manufacturer: string = "Samsung"): string[] {

    let MobileList: string[];

    if (manufacturer == "Samsung") {
        MobileList = ["Samsung Galaxy S6 Edge", "Samsung Galaxy Note 7", "Samsung Galaxy J7 SM-J700F"];
        return MobileList;
    }

    else if (manufacturer == "Apple") {
        MobileList = ["Apple iPhone 5s", "Apple iPhone 6s ", "Apple iPhone 7"];
        return MobileList;
    }

    else {
        MobileList = ["Nokia 105", "Nokia 230 Dual Sim"];
        return MobileList;
    }

}

function getMobileByManufacturerOrId(manufacturer: string = "Samsung", id?: number): string[] {  // Adding ? after parameter name makes parameter,optional

    let MobileList: string[];

    if (id) {
        if (id == 101) {
            MobileList = ["Moto G Play, 4th Gen", "Moto Z Play with Style Mod"];
            return MobileList;
        }
    }

    if (manufacturer == "Samsung") {
        MobileList = ["Samsung Galaxy S6 Edge", "Samsung Galaxy Note 7", "Samsung Galaxy J7 SM-J700F"];
        return MobileList;
    }

    else if (manufacturer == "Apple") {
        MobileList = ["Apple iPhone 5s", "Apple iPhone 6s ", "Apple iPhone 7"];
        return MobileList;
    }

    else {
        MobileList = ["Nokia 105", "Nokia 230 Dual Sim"];
        return MobileList;
    }

}

//to test the optional parameter

console.log("The available mobile list:" + getMobileByManufacturer("Apple"));

//to test the default parameter

console.log("The available mobile list:" + getMobileByManufacturer());

//to test the optional parameter

console.log("The available mobile list:" + getMobileByManufacturerOrId("Apple"));

//to test the default parameter
//Pass undefined as value for default parameter.

console.log("The available mobile list:" + getMobileByManufacturerOrId(undefined, 101)); 