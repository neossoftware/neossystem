import { Product } from './Product';

let prod = new Product(123,"mobile");

prod.display();
