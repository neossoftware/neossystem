export class Product{
    product_id: number;
    product_name: string;

    constructor(product_id,product_name){
        this.product_id = product_id;
        this.product_name = product_name;
    }

    display(){
        console.log(this.product_id+" : "+this.product_name);
    }

}