package com.infybank.create;

public interface ICustomer {
	public void addCustomer(Customer custObj);
}
