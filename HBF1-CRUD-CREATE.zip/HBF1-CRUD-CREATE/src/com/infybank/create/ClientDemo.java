package com.infybank.create;

import java.util.Scanner;

import org.hibernate.HibernateException;

public class ClientDemo {
	public static void main(String[] args) {
		CustomerDAO custdao = new CustomerDAO();
		try {
			System.out.println("CREATE");
			System.out.println("Enter the customer details");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the customer number");
			int id = sc.nextInt();
			System.out.println("Enter the Customer name");
			String name = sc.next();
			
			Customer cust = new Customer(id, name);
			custdao.addCustomer(cust);
			
			System.out.println("One record created");
			sc.close();
		}
		catch(HibernateException e) {
			System.out.println("Exception" + e);
		}
	}
}
